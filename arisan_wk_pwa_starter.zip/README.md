# Arisan WK PWA

Aplikasi web ringan untuk pengelolaan Arisan WK. Bisa di-install di Android lewat browser sebagai PWA.

## Login
Username: `admin`
Password: `wk788748`

## Deploy ke GitHub Pages
1. Buat repository baru, misalnya `arisan-wk-pwa`.
2. Upload isi folder ini ke repository.
3. Buka Settings > Pages.
4. Source: Deploy from a branch.
5. Branch: main, folder: `/root`.
6. Buka URL GitHub Pages.
7. Di Android Chrome, pilih menu titik tiga > Install app / Add to Home Screen.

## Catatan
- Data disimpan lokal di browser.
- Backup berupa JSON masuk ke folder Download.
- Restore dilakukan dengan memilih file JSON backup.
- Jangan clear data browser/site kalau belum backup.


Update login fixed v2: tombol login memakai event listener dan cache service worker dinaikkan agar tidak nyangkut versi lama.
