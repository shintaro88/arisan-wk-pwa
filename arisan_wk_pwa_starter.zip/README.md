# Arisan WK PWA

Versi PWA ringan untuk pengelolaan Arisan WK.

Login:
- username: admin
- password: wk788748

Catatan deploy:
- Upload ZIP dengan nama `arisan_wk_pwa_starter.zip`.
- Workflow GitHub Pages tidak perlu diganti.
- Setelah deploy, buka dengan `?refresh=4` jika browser masih menyimpan cache lama.


Update: Tombol Backup/Restore/Reset dibuat konsisten ukurannya. Restore PWA menggunakan file JSON. Backup APK .db perlu dikonversi ke JSON sebelum di-restore ke PWA.
