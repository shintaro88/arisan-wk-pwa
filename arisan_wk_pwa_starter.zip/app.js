const ADMIN_USER='admin', ADMIN_PASS='wk788748';
const MONTHS=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const storeKey='arisan_wk_pwa_v2'; let state=loadState(); let deferredPrompt=null;
function defaultState(){return{settings:{orgName:'Wanita Katolik',bendahara:'',defaultArisan:50000,defaultKas:10000,activeArisanMonth:''},members:[],arisanPeriods:[],arisanPayments:[],kasPayments:[],kasTransactions:[],session:false}}
function loadState(){try{const raw=localStorage.getItem(storeKey);return raw?normalizeAppData({...defaultState(),...JSON.parse(raw)}):defaultState()}catch(e){return defaultState()}}
function saveState(){localStorage.setItem(storeKey,JSON.stringify(state))}
function uid(p='id'){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
function currentMonth(d=new Date()){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  return `${y}-${m}`;
}
function todayIso(d=new Date()){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  const day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function normalizeMonthText(text){return String(text||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')}
function inferMonthFromText(text,fallbackYm){const raw=normalizeMonthText(text);const yearMatch=raw.match(/(20\d{2})/);const fallbackYear=String(fallbackYm||currentMonth()).slice(0,4);const year=yearMatch?yearMatch[1]:fallbackYear;const tokens=[['januari','jan',1],['februari','feb',2],['maret','mar',3],['april','apr',4],['mei','may',5],['juni','jun',6],['juli','jul',7],['agustus','agu',8],['august','aug',8],['september','sep',9],['oktober','okt',10],['october','oct',10],['november','nov',11],['desember','des',12],['december','dec',12]];for(const [full,short,num] of tokens){const reFull=new RegExp('(^|[^a-z])'+full+'([^a-z]|$)');const reShort=new RegExp('(^|[^a-z])'+short+'([^a-z]|$)');if(reFull.test(raw)||reShort.test(raw)){return year+'-'+String(num).padStart(2,'0')}}return fallbackYm||currentMonth()}
function normalizeAppData(data){const d={...defaultState(),...data};d.settings={...defaultState().settings,...(data?.settings||{})};d.members=Array.isArray(d.members)?d.members:[];d.arisanPeriods=Array.isArray(d.arisanPeriods)?d.arisanPeriods:[];d.arisanPayments=Array.isArray(d.arisanPayments)?d.arisanPayments:[];d.kasPayments=Array.isArray(d.kasPayments)?d.kasPayments:[];d.kasTransactions=Array.isArray(d.kasTransactions)?d.kasTransactions:[];d.arisanPeriods=d.arisanPeriods.map(p=>{const label=[p.namaPeriode,p.name,p.title,p.note].filter(Boolean).join(' ');const inferred=label?inferMonthFromText(label,p.month):p.month;return {...p,month:inferred||p.month||currentMonth(),amount:Number(p.amount||d.settings.defaultArisan||0)}});d.arisanPayments=d.arisanPayments.map(p=>{const sumber=p.sumberBayar||((p.method||'')==='Ditalangi Kas WK'?'talangan':'pribadi');const status=sumber==='talangan'?(p.statusTalangan||'aktif'):(p.statusTalangan||'-');return {...p,sumberBayar:sumber,statusTalangan:status,amount:Number(p.amount||0)}});return d}
function compactMonths(months){
  const seen=new Set();
  return months.filter(Boolean).filter(m=>{
    const key=String(m).toLowerCase();
    if(seen.has(key))return false;
    seen.add(key);
    return true;
  }).join(' - ');
}
function monthShort(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return String(ym||'-');
  const [y,m]=ym.split('-').map(Number);
  return `${MONTHS[m-1]?.slice(0,3)||''} ${y}`;
}
function monthName(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return String(ym||'-');
  const [y,m]=ym.split('-').map(Number);
  return `${MONTHS[m-1]||''} ${y}`;
}
function monthOnly(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return String(ym||'-');
  const [,m]=ym.split('-').map(Number);
  return MONTHS[m-1]||String(ym||'-');
}
function yearOfMonth(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return '-';
  return String(ym).slice(0,4);
}
function dateNoYear(iso){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(iso||''))) return String(iso||'-');
  const [,m,d]=String(iso).split('-').map(Number);
  return `${String(d).padStart(2,'0')} ${MONTHS[m-1]?.slice(0,3)||''}`;
}
function yearOfDate(iso){
  if(!/^\d{4}/.test(String(iso||''))) return '-';
  return String(iso).slice(0,4);
}
function compactMonthOnly(months){
  const seen=new Set();
  return months.filter(Boolean).map(monthOnly).filter(m=>{
    const key=String(m).toLowerCase();
    if(seen.has(key))return false;
    seen.add(key);
    return true;
  }).join(' - ');
}
function splitDueRowsByYear(dueRows){
  const result=[];
  dueRows.forEach(r=>{
    const grouped={};
    (r.months||[]).forEach(ym=>{
      const y=yearOfMonth(ym);
      grouped[y]=grouped[y]||[];
      grouped[y].push(ym);
    });
    Object.keys(grouped).sort().forEach(y=>{
      const months=grouped[y].sort();
      const totalPerMonth=(r.months?.length?Number(r.total||0)/r.months.length:0);
      result.push({member:r.member,year:y,months,total:months.length*totalPerMonth,note:r.note||''});
    });
  });
  return result;
}
function money(n){return 'Rp '+Number(n||0).toLocaleString('id-ID')}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),3500)}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}

function safeText(v){return escapeHtml(v==null?'-':v)}
function modalSummaryCard(label,value,hint=''){
  return `<div class="modal-summary-card"><span>${safeText(label)}</span><b>${safeText(value)}</b>${hint?`<small>${safeText(hint)}</small>`:''}</div>`;
}
function modalEmpty(text){return `<div class="modal-empty">${safeText(text)}</div>`}
function modalTable(headers,rows){
  if(!rows.length)return modalEmpty('Tidak ada data.');
  return `<div class="modal-table-wrap"><table class="modal-table"><thead><tr>${headers.map(h=>`<th>${safeText(h)}</th>`).join('')}</tr></thead><tbody>${rows.map((r,i)=>`<tr style="background:${pastel(i)}">${r.map((c,idx)=>`<td>${idx===0?'<b>':''}${safeText(c)}${idx===0?'</b>':''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function showInfoModal({title,subtitle='',summary=[],body='',note=''}){
  let modal=document.getElementById('infoModal');
  if(!modal){
    modal=document.createElement('div');
    modal.id='infoModal';
    modal.className='modal-backdrop hidden';
    modal.innerHTML=`<div class="modal-panel" role="dialog" aria-modal="true"><button class="modal-close" onclick="closeInfoModal()" aria-label="Tutup">×</button><div class="modal-header"><h2 id="infoModalTitle"></h2><p id="infoModalSubtitle"></p></div><div id="infoModalSummary" class="modal-summary"></div><div id="infoModalBody" class="modal-body"></div><p id="infoModalNote" class="modal-note"></p><div class="modal-footer"><button class="btn primary" onclick="closeInfoModal()">Mengerti</button></div></div>`;
    modal.addEventListener('click',e=>{if(e.target===modal)closeInfoModal()});
    document.body.appendChild(modal);
  }
  document.getElementById('infoModalTitle').textContent=title||'Detail';
  const sub=document.getElementById('infoModalSubtitle');
  sub.textContent=subtitle||'';sub.style.display=subtitle?'block':'none';
  document.getElementById('infoModalSummary').innerHTML=summary.length?summary.join(''):'';
  document.getElementById('infoModalBody').innerHTML=body||modalEmpty('Tidak ada data.');
  const nt=document.getElementById('infoModalNote');nt.textContent=note||'';nt.style.display=note?'block':'none';
  modal.classList.remove('hidden');
}
function closeInfoModal(){document.getElementById('infoModal')?.classList.add('hidden')}
function normalizeName(s){return String(s||'').trim().replace(/\s+/g,' ').toLowerCase()}
function parseAmount(v){v=String(v||'').trim();if(!/^\d+$/.test(v))throw new Error('Nominal hanya boleh angka tanpa titik, koma, Rp, atau simbol lain.');return Number(v)}
function activeMembers(){return state.members.filter(m=>m.active!==false)} function kasMembers(){return activeMembers().filter(m=>m.ikutKas)} function arisanMembers(){return activeMembers().filter(m=>m.ikutArisan)}
function findMember(id){return state.members.find(m=>m.id===id)}
function memberDisplayName(id){return findMember(id)?.name||'-'}
function paymentMemberOptions(kind,currentId){
  const base=(kind==='kas'?kasMembers():arisanMembers()).slice();
  const current=findMember(currentId);
  if(current&&!base.some(m=>m.id===current.id))base.push(current);
  return base.sort((a,b)=>a.name.localeCompare(b.name)).map(m=>`<option value="${m.id}" ${m.id===currentId?'selected':''}>${escapeHtml(m.name)}${m.active===false?' (nonaktif)':''}</option>`).join('');
}
function selectedOption(value,current){return String(value||'')===String(current||'')?'selected':''}
function getKasPayment(month,memberId){return state.kasPayments.find(p=>p.month===month&&p.memberId===memberId)}
function replaceKasIuranTransaction(month){
  if(!month)return;
  state.kasTransactions=state.kasTransactions.filter(t=>!(t.type==='in'&&isIuranKasTransaction(t)&&inferKasMonthFromTransaction(t)===month));
  const pays=state.kasPayments.filter(p=>p.month===month);
  if(pays.length){
    state.kasTransactions.push({id:uid('kt'),date:todayIso(),type:'in',category:'Iuran Kas',amount:pays.reduce((a,b)=>a+Number(b.amount||0),0),note:`Iuran kas ${monthName(month)} (${pays.length} anggota)`,referensi:`kas:${month}`});
  }
}
function paymentStatusBadge(status){
  const label=status==='paid'?'Lunas':status==='talangan'?'Talangan Aktif':status==='talanganLunas'?'Talangan Lunas':'Belum';
  const cls=status==='paid'?'ok':status==='talangan'?'warn':status==='talanganLunas'?'blue':'danger';
  return `<span class="badge ${cls}">${label}</span>`;
}
function arisanPaymentForMember(periodId,memberId){return state.arisanPayments.find(p=>p.periodId===periodId&&p.memberId===memberId)}
function talanganPaymentLabel(p){
  if(p?.sumberBayar==='talangan')return p.statusTalangan==='lunas'?'talanganLunas':'talangan';
  return 'paid';
}
function linkedTalanganMatch(t,p,kind){
  if(!t||!p)return false;
  const cat=String(t.category||'').toLowerCase();
  if(kind==='out' && !(t.type==='out'&&cat.includes('talangan arisan')))return false;
  if(kind==='in' && !(t.type==='in'&&cat.includes('pengembalian talangan')))return false;
  if(t.referensi===p.id||t.paymentId===p.id)return true;
  if(Number(t.amount||0)!==Number(p.amount||0))return false;
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  const note=normalizeMonthText([t.note,t.referensi].filter(Boolean).join(' '));
  const memberHit=m?note.includes(normalizeName(m.name)):false;
  const periodToken=per?.id?String(per.id).split('_').pop():'';
  const periodHit=per&&(note.includes(normalizeMonthText(monthName(per.month)))||note.includes(normalizeMonthText(per.namaPeriode||''))||note.includes(normalizeMonthText(per.id))||(periodToken&&note.includes(`periode: ${periodToken}`)));
  const dateHit=p.date&&t.date===p.date;
  return Boolean(memberHit||periodHit||dateHit);
}
function removeLinkedTalanganCashflow(p){
  state.kasTransactions=state.kasTransactions.filter(t=>!(linkedTalanganMatch(t,p,'out')||linkedTalanganMatch(t,p,'in')));
}
function syncTalanganCashflow(p){
  removeLinkedTalanganCashflow(p);
  if(!p||p.sumberBayar!=='talangan')return;
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  state.kasTransactions.push({id:uid('kt'),date:p.date||todayIso(),type:'out',category:'Talangan Arisan',amount:Number(p.amount||0),note:`Talangan arisan ${m?.name||''} periode ${per?monthName(per.month):'-'}`,referensi:p.id});
  if(p.statusTalangan==='lunas'){
    const date=p.tanggalPelunasanTalangan||todayIso();
    p.tanggalPelunasanTalangan=date;
    state.kasTransactions.push({id:uid('kt'),date,type:'in',category:'Pengembalian Talangan',amount:Number(p.amount||0),note:`Pengembalian talangan arisan ${m?.name||''} periode ${per?monthName(per.month):'-'}`,referensi:p.id});
  }
}

function handleLogin(){const u=document.getElementById('loginUser').value.trim();const p=document.getElementById('loginPass').value;if(u===ADMIN_USER&&p===ADMIN_PASS){state.session=true;saveState();document.getElementById('loginMsg').textContent='';boot();setPage('dashboard');toast('Login berhasil.')}else{document.getElementById('loginMsg').textContent='Username atau password salah.'}}
function logout(){state.session=false;saveState();location.reload()}
function boot(){state=normalizeAppData(state);saveState();const loginPage=document.getElementById('loginPage');const appShell=document.getElementById('app');if(state.session){loginPage.classList.add('hidden');appShell.classList.remove('hidden');orgNameDrawer.textContent=state.settings.orgName;todayText.textContent=new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});renderAll()}else{loginPage.classList.remove('hidden');appShell.classList.add('hidden')}}
function renderAll(){renderDashboard();renderAnggota();renderArisan();renderKas();renderLaporan();renderPengaturan()}
function setPage(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));pageTitle.textContent=({dashboard:'Dashboard',anggota:'Data Anggota',arisan:'Arisan',kas:'Kas WK',laporan:'Laporan',pengaturan:'Pengaturan'})[page]||'Dashboard';drawer.classList.remove('open')}
function toggleDrawer(){drawer.classList.toggle('open')} document.addEventListener('click',e=>{const nav=e.target.closest('.nav[data-page]');if(nav)setPage(nav.dataset.page)});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;installBtn.classList.remove('hidden')}); installBtn?.addEventListener('click',async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null}}); if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js'));
function getCurrentDueArisanPeriod(){
  const ps=[...state.arisanPeriods].sort((a,b)=>String(a.month).localeCompare(String(b.month)));
  if(!ps.length)return null;
  const activeMonth=state.settings.activeArisanMonth;
  const active=activeMonth?ps.find(p=>p.month===activeMonth):null;
  if(active)return active;
  const cm=currentMonth();
  const current=ps.find(p=>p.month===cm);
  if(current)return current;
  const latestPast=[...ps].filter(p=>String(p.month||'')<=cm).sort((a,b)=>String(b.month).localeCompare(String(a.month)))[0];
  if(latestPast)return latestPast;
  return ps[0];
}
function kasPaymentAmountByMonth(){
  const map={};
  state.kasPayments.forEach(p=>{
    if(!p.month)return;
    map[p.month]=(map[p.month]||0)+Number(p.amount||0);
  });
  return map;
}
function inferKasMonthFromTransaction(t){
  const text=[t?.note,t?.category,t?.date].filter(Boolean).join(' ');
  return inferMonthFromText(text,String(t?.date||'').slice(0,7)||currentMonth());
}
function isIuranKasTransaction(t){
  return String(t?.category||'').toLowerCase().includes('iuran kas');
}
function effectiveKasTransactions(){
  const byPay=kasPaymentAmountByMonth();
  const hasPaymentMonth=new Set(Object.keys(byPay));
  const represented=new Set();
  const result=[];
  [...state.kasTransactions].sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))).forEach(t=>{
    if(t.type==='in'&&isIuranKasTransaction(t)){
      const ym=inferKasMonthFromTransaction(t);
      if(hasPaymentMonth.has(ym)){
        if(represented.has(ym))return;
        represented.add(ym);
        result.push({...t,amount:byPay[ym],note:`Iuran kas ${monthName(ym)} (${state.kasPayments.filter(p=>p.month===ym).length} anggota)`,_consolidated:true});
        return;
      }
    }
    result.push(t);
  });
  Object.keys(byPay).sort().forEach(ym=>{
    if(!represented.has(ym)){
      result.push({id:'calc_'+ym,date:ym+'-01',type:'in',category:'Iuran Kas',amount:byPay[ym],note:`Iuran kas ${monthName(ym)} (${state.kasPayments.filter(p=>p.month===ym).length} anggota)`,_consolidated:true});
    }
  });
  return result;
}
function kasEffectiveTotals(endMonth=''){
  const tx=effectiveKasTransactions().filter(t=>!endMonth||String(t.date||'').slice(0,7)<=endMonth);
  const pemasukan=tx.filter(t=>t.type==='in').reduce((a,b)=>a+Number(b.amount||0),0);
  const pengeluaran=tx.filter(t=>t.type==='out').reduce((a,b)=>a+Number(b.amount||0),0);
  return{tx,pemasukan,pengeluaran,saldo:pemasukan-pengeluaran};
}
function calcSaldoKas(){
  return kasEffectiveTotals().saldo;
}
function rawKasInTotal(){
  return state.kasTransactions.filter(t=>t.type==='in').reduce((a,b)=>a+Number(b.amount||0),0);
}
function getReportMonths(){
  const months=new Set();
  state.kasPayments.forEach(p=>p.month&&months.add(p.month));
  state.arisanPeriods.forEach(p=>p.month&&months.add(p.month));
  state.kasTransactions.forEach(t=>{
    if(t.type==='in'&&isIuranKasTransaction(t))months.add(inferKasMonthFromTransaction(t));
  });
  return [...months].filter(m=>/^\d{4}-\d{2}$/.test(m)).sort();
}
function getKasReportStartMonth(endMonth=currentMonth()){
  const months=getReportMonths().filter(m=>m<=endMonth);
  return months[0]||endMonth;
}
function reportEndMonth(){
  return document.getElementById('reportEndMonth')?.value||currentMonth();
}
function monthsBetween(startYm,endYm){let[sy,sm]=startYm.split('-').map(Number),[ey,em]=endYm.split('-').map(Number);const arr=[];while(sy<ey||(sy===ey&&sm<=em)){arr.push(`${sy}-${String(sm).padStart(2,'0')}`);sm++;if(sm>12){sm=1;sy++}}return arr}

function arisanPeriodAmount(){return Number(state.settings.defaultArisan||0)}
function kasDefaultAmount(){return Number(state.settings.defaultKas||0)}
function ensureArisanPeriod(month){
  if(!month)return null;
  let per=state.arisanPeriods.find(p=>p.month===month);
  if(!per){
    per={id:uid('ap'),month,amount:arisanPeriodAmount(),receiverName:'',note:'',status:'Aktif',autoCreated:true,namaPeriode:`Arisan ${monthName(month)}`};
    state.arisanPeriods.push(per);
  }else{
    per.amount=Number(per.amount||arisanPeriodAmount());
  }
  return per;
}
function activeTalanganPayments(){return state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas')}
function activeTalanganPeriods(){
  const ids=new Set(activeTalanganPayments().map(p=>p.periodId));
  return state.arisanPeriods.filter(p=>ids.has(p.id)).sort((a,b)=>String(b.month).localeCompare(String(a.month)));
}
function getVisibleArisanPeriods(){
  const active=getCurrentDueArisanPeriod();
  const list=[];
  if(active)list.push(active);
  activeTalanganPeriods().forEach(p=>{if(!list.some(x=>x.id===p.id))list.push(p)});
  if(!list.length&&state.arisanPeriods.length)list.push([...state.arisanPeriods].sort((a,b)=>String(b.month).localeCompare(String(a.month)))[0]);
  return list;
}
function arisanPeriodLabel(p){
  const active=getCurrentDueArisanPeriod();
  const hasTalangan=activeTalanganPayments().some(x=>x.periodId===p.id);
  const tags=[];
  if(active&&p.id===active.id)tags.push('periode berjalan');
  if(hasTalangan)tags.push('ada talangan');
  return `${monthName(p.month)}${tags.length?' - '+tags.join(', '):''}`;
}
function getKasDueRowsUntil(endMonth){
  const first=getKasReportStartMonth(endMonth);
  const months=monthsBetween(first,endMonth);
  const rows=[];
  let totalDue=0,totalPaid=0,totalNominalBelum=0;
  for(const m of kasMembers().sort((a,b)=>a.name.localeCompare(b.name))){
    const unpaid=[];
    for(const ym of months){
      totalDue++;
      const paid=state.kasPayments.some(p=>p.month===ym&&p.memberId===m.id);
      if(paid)totalPaid++;
      else unpaid.push(ym);
    }
    if(unpaid.length){
      const total=unpaid.length*Number(state.settings.defaultKas||0);
      totalNominalBelum+=total;
      rows.push({member:m,months:unpaid,total});
    }
  }
  return{unpaidRows:rows,totalDue,totalPaid,totalNominalBelum,months};
}
function dashboardData(){const cm=currentMonth(),period=getCurrentDueArisanPeriod(),am=arisanMembers(),km=kasMembers();const paid=period?new Set(state.arisanPayments.filter(p=>p.periodId===period.id).map(p=>p.memberId)):new Set();const belumArisan=period?am.filter(m=>!paid.has(m.id)):[];const kasDue=getKasDueRowsUntil(cm);const talangan=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas');const totals=kasEffectiveTotals();const rawIn=rawKasInTotal();return{cm,active:activeMembers(),am,km,period,belumArisan,kasDue,talangan,saldoKas:totals.saldo,pemasukanKas:totals.pemasukan,pengeluaranKas:totals.pengeluaran,rawKasIn:rawIn,kasInSelisih:Math.max(rawIn-totals.pemasukan,0)}}
function renderDashboard(){
  const d=dashboardData();
  const arisanTotal=d.period?d.am.length:0;
  const arisanPaid=d.period?arisanTotal-d.belumArisan.length:0;
  const arisanPct=arisanTotal?Math.round(arisanPaid/arisanTotal*100):0;
  const kasPct=d.kasDue.totalDue?Math.round(d.kasDue.totalPaid/d.kasDue.totalDue*100):0;
  dashboard.innerHTML=`<div class="card"><h3>Monitoring ${escapeHtml(state.settings.orgName)}</h3><p style="color:var(--muted);margin-top:0">Ringkasan arisan, kas, dan talangan dalam satu dashboard.</p><div class="grid two"><div class="card"><h3>Progress Arisan</h3><strong>${arisanPaid}/${arisanTotal} orang</strong><div class="progress"><span style="width:${arisanPct}%"></span></div><small>${d.period?monthName(d.period.month):'Belum ada periode arisan'}</small></div><div class="card"><h3>Progress Kas sampai Bulan Ini</h3><strong>${d.kasDue.totalPaid}/${d.kasDue.totalDue} catatan</strong><div class="progress"><span style="width:${kasPct}%"></span></div><small>Tunggakan kas dihitung sampai ${monthName(d.cm)}</small></div></div></div><h3 class="section-title">Tagihan & Talangan</h3><div class="grid four">${kpi('Belum Bayar Arisan',d.belumArisan.length,'warning','detailBelumArisan()','Klik untuk lihat nama')}${kpi('Belum Bayar Kas',d.kasDue.unpaidRows.length,'warn','detailBelumKas()','Klik untuk lihat nama')}${kpi('Talangan Aktif',d.talangan.length,'primary','detailTalangan()',money(d.talangan.reduce((a,b)=>a+Number(b.amount||0),0)))}${kpi('Penerima arisan terakhir',lastReceiverLabel(),'blue','detailPenerima()','Klik untuk detail')}</div><h3 class="section-title">Ringkasan Uang Kas</h3><p style="color:var(--muted);margin-top:-6px">Saldo kas dihitung otomatis dari pembayaran anggota dan pengeluaran kas yang tercatat.</p><div class="grid four">${kpi('Saldo Kas Saat Ini',money(d.saldoKas),'ok','detailSaldoKas()','Klik untuk lihat ringkasan')}${kpi('Uang Kas Masuk',money(d.pemasukanKas),'blue','detailPemasukanKas()','Klik untuk lihat rincian')}${kpi('Uang Kas Keluar',money(d.pengeluaranKas),'danger','detailPengeluaranKas()','Klik untuk lihat rincian')}${kpi('Anggota Aktif',d.active.length,'primary','detailAnggotaAktif()','Klik untuk lihat daftar')}</div>`
}
function kpi(label,value,type,action,hint='Klik untuk detail'){const colors={warning:'#df795f',warn:'#c58b31',primary:'#8a61b4',ok:'#30a46c',blue:'#4a91c5',danger:'#d36a4b'};return`<div class="card kpi" onclick="${action}" style="--primary:${colors[type]||'#7B5A91'}"><div><div class="value">${escapeHtml(value)}</div><div class="label">${escapeHtml(label)}</div></div><div class="hint">${escapeHtml(hint)}</div></div>`}
function detailBelumArisan(){
  const d=dashboardData();
  const rows=d.belumArisan.map(m=>[m.name,'Belum bayar',money(arisanPeriodAmount())]);
  showInfoModal({
    title:'Belum Bayar Arisan',
    subtitle:d.period?`Periode ${monthName(d.period.month)}`:'Belum ada periode arisan',
    summary:[modalSummaryCard('Jumlah belum bayar',`${d.belumArisan.length} anggota`),modalSummaryCard('Perkiraan nominal',money(d.belumArisan.length*arisanPeriodAmount()))],
    body:modalTable(['Nama','Status','Nominal'],rows),
    note:d.belumArisan.length?'Nama di atas belum tercatat membayar arisan pada periode ini.':'Semua anggota arisan sudah tercatat lunas.'
  });
}
function detailBelumKas(){
  const d=dashboardData();
  const rows=splitDueRowsByYear(d.kasDue.unpaidRows).map(x=>[x.member.name,x.year,compactMonthOnly(x.months),money(x.total)]);
  showInfoModal({
    title:'Belum Bayar Kas',
    subtitle:`Dihitung sampai ${monthName(d.cm)}`,
    summary:[modalSummaryCard('Jumlah anggota',`${d.kasDue.unpaidRows.length} anggota`),modalSummaryCard('Total belum bayar',money(d.kasDue.totalNominalBelum))],
    body:modalTable(['Nama','Tahun','Bulan yang belum dibayar','Total'],rows),
    note:d.kasDue.unpaidRows.length?'Satu nama bisa punya beberapa bulan yang belum dibayar.':'Semua iuran kas sampai bulan ini sudah tercatat lunas.'
  });
}
function detailTalangan(){
  const d=dashboardData();
  const rows=d.talangan.map(p=>{const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return[m?.name||'-',per?yearOfMonth(per.month):'-',per?monthOnly(per.month):'-',money(p.amount),'Belum diganti ke kas']});
  showInfoModal({
    title:'Talangan Aktif',
    subtitle:'Uang kas yang sementara dipakai untuk menalangi arisan',
    summary:[modalSummaryCard('Jumlah talangan',`${d.talangan.length} transaksi`),modalSummaryCard('Total talangan',money(d.talangan.reduce((a,b)=>a+Number(b.amount||0),0)))],
    body:modalTable(['Nama','Tahun','Bulan','Nominal','Status'],rows),
    note:d.talangan.length?'Jika sudah diganti oleh anggota, buka menu Arisan lalu tandai lunas agar uang kembali ke kas.':'Tidak ada talangan aktif.'
  });
}
function detailPenerima(){
  const rows=state.arisanPeriods.filter(p=>p.receiverName).sort((a,b)=>String(b.month).localeCompare(String(a.month))).map(p=>[p.receiverName,yearOfMonth(p.month),monthOnly(p.month),p.note||'-']);
  showInfoModal({title:'Penerima Arisan Terakhir',subtitle:'Riwayat penerima yang sudah diisi',summary:[modalSummaryCard('Penerima terakhir',lastReceiverLabel())],body:modalTable(['Nama','Tahun','Bulan','Catatan'],rows),note:rows.length?'Data diambil dari isian penerima pada menu Arisan.':'Belum ada penerima arisan yang diisi.'});
}
function detailPemasukanKas(){
  const tx=kasEffectiveTotals().tx.filter(t=>t.type==='in').sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  const rows=tx.map(t=>[dateNoYear(t.date),yearOfDate(t.date),t.category||'Pemasukan',money(t.amount),String(t.note||'')]);
  showInfoModal({title:'Uang Kas Masuk',subtitle:'Rincian uang yang menambah kas',summary:[modalSummaryCard('Total uang masuk',money(tx.reduce((a,b)=>a+Number(b.amount||0),0)))],body:modalTable(['Tanggal','Tahun','Sumber','Nominal','Keterangan'],rows),note:'Uang masuk berasal dari iuran kas anggota dan pengembalian talangan yang sudah lunas.'});
}
function detailPengeluaranKas(){
  const tx=kasEffectiveTotals().tx.filter(t=>t.type==='out').sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')));
  const rows=tx.map(t=>[dateNoYear(t.date),yearOfDate(t.date),t.category||'Pengeluaran',money(t.amount),t.note||'']);
  showInfoModal({title:'Uang Kas Keluar',subtitle:'Rincian uang yang mengurangi kas',summary:[modalSummaryCard('Total uang keluar',money(tx.reduce((a,b)=>a+Number(b.amount||0),0)))],body:modalTable(['Tanggal','Tahun','Keperluan','Nominal','Keterangan'],rows),note:'Uang keluar termasuk talangan arisan dan pengeluaran kas lain yang tercatat.'});
}
function detailSaldoKas(){
  const totals=kasEffectiveTotals();
  const rows=[['Uang Kas Masuk',money(totals.pemasukan)],['Uang Kas Keluar',money(totals.pengeluaran)],['Saldo Kas Saat Ini',money(totals.saldo)]];
  showInfoModal({title:'Saldo Kas Saat Ini',subtitle:'Ringkasan posisi uang kas',summary:[modalSummaryCard('Saldo saat ini',money(totals.saldo)),modalSummaryCard('Uang masuk',money(totals.pemasukan)),modalSummaryCard('Uang keluar',money(totals.pengeluaran))],body:modalTable(['Keterangan','Nominal'],rows),note:'Saldo kas adalah uang masuk dikurangi uang keluar.'});
}
function detailAnggotaAktif(){
  const rows=activeMembers().sort((a,b)=>a.name.localeCompare(b.name)).map(m=>[m.name,m.ikutKas?'Ikut':'Tidak',m.ikutArisan?'Ikut':'Tidak']);
  showInfoModal({title:'Anggota Aktif',subtitle:'Daftar anggota yang masih aktif',summary:[modalSummaryCard('Total anggota aktif',`${rows.length} orang`),modalSummaryCard('Ikut kas',`${kasMembers().length} orang`),modalSummaryCard('Ikut arisan',`${arisanMembers().length} orang`)],body:modalTable(['Nama','Kas','Arisan'],rows)});
}
function lastReceiverLabel(){const r=state.arisanPeriods.filter(p=>p.receiverName).sort((a,b)=>String(b.month).localeCompare(String(a.month)));return r[0]?.receiverName||'-'}
function renderAnggota(){anggota.innerHTML=`<div class="card"><h3>Tambah Anggota</h3><div class="row"><div><label>Nama anggota</label><input id="memberName" placeholder="Nama lengkap"></div><div><label>Wilayah / Lingkungan</label><input id="memberWilayah" placeholder="Opsional"></div></div><div class="actions"><label><input type="checkbox" id="memberKas" checked style="width:auto"> Ikut Kas WK</label><label><input type="checkbox" id="memberArisan" checked style="width:auto"> Ikut Arisan</label></div><button class="primary" onclick="addMember()">Simpan Anggota</button></div><div class="card" style="margin-top:16px"><h3>Daftar Anggota</h3><input id="searchMember" placeholder="Cari nama anggota..." oninput="renderMemberTable()"><div id="memberTable" style="margin-top:12px"></div></div>`;renderMemberTable()}
function addMember(){const name=memberName.value.trim().replace(/\s+/g,' ');if(!name)return toast('Nama anggota wajib diisi.');if(state.members.some(m=>normalizeName(m.name)===normalizeName(name)))return toast('Nama anggota persis sama sudah ada.');state.members.push({id:uid('m'),name,wilayah:memberWilayah.value.trim(),ikutKas:memberKas.checked,ikutArisan:memberArisan.checked,active:true});saveState();toast('Anggota tersimpan.');renderAll()}
function renderMemberTable(){const q=(document.getElementById('searchMember')?.value||'').toLowerCase();const rows=state.members.filter(m=>m.name.toLowerCase().includes(q)).sort((a,b)=>a.name.localeCompare(b.name));memberTable.innerHTML=`<div class="table-wrap"><table><thead><tr><th>Nama</th><th>Wilayah</th><th>Kas</th><th>Arisan</th><th>Status</th><th>Aksi</th></tr></thead><tbody>${rows.map(m=>`<tr><td><b>${escapeHtml(m.name)}</b></td><td>${escapeHtml(m.wilayah||'-')}</td><td>${m.ikutKas?'Ya':'Tidak'}</td><td>${m.ikutArisan?'Ya':'Tidak'}</td><td>${m.active!==false?'Aktif':'Nonaktif'}</td><td><button class="btn" onclick="toggleMember('${m.id}')">${m.active!==false?'Nonaktifkan':'Aktifkan'}</button></td></tr>`).join('')}</tbody></table></div>`}
function toggleMember(id){const m=state.members.find(x=>x.id===id);if(m){m.active=!(m.active!==false);saveState();renderAll()}}
function renderArisan(){
  const active=getCurrentDueArisanPeriod();
  const visible=getVisibleArisanPeriods();
  const selected=visible[0];
  const monthValue=active?.month||state.settings.activeArisanMonth||currentMonth();
  const talanganHtml=renderActiveTalanganArisan();
  arisan.innerHTML=`<div class="card"><h3>Periode Arisan Berjalan</h3><p style="color:var(--muted);margin-top:0">Nominal iuran arisan mengikuti Pengaturan: <b>${money(arisanPeriodAmount())}</b>. Field nominal tidak ditampilkan di sini supaya tidak ambigu.</p><div class="row"><div><label>Bulan periode berjalan</label><input id="arisanMonth" type="month" value="${monthValue}"></div><div><label>Penerima arisan</label><input id="receiverName" placeholder="Isi jika sudah ada penerima" value="${escapeHtml(active?.receiverName||'')}"></div></div><div class="row"><div><label>Catatan</label><input id="periodNote" placeholder="Opsional" value="${escapeHtml(active?.note||'')}"></div><div><label>Nominal dari pengaturan</label><input value="${money(arisanPeriodAmount())}" disabled></div></div><button class="primary" onclick="addArisanPeriod()">Simpan / Update Periode Berjalan</button></div>${talanganHtml}<div class="card" style="margin-top:16px"><h3>Pembayaran Arisan</h3><label>Periode yang ditampilkan</label><select id="payPeriod" onchange="renderArisanPaymentBox()">${visible.map(p=>`<option value="${p.id}" ${selected&&p.id===selected.id?'selected':''}>${escapeHtml(arisanPeriodLabel(p))}</option>`).join('')}</select><small style="display:block;color:var(--muted);margin-top:6px">Input rutin hanya fokus ke periode berjalan. Periode lama tetap muncul jika masih ada talangan aktif.</small><div id="arisanPaymentBox"></div></div>`;
  renderArisanPaymentBox();
}
function renderActiveTalanganArisan(){
  const rows=activeTalanganPayments().sort((a,b)=>{const pa=state.arisanPeriods.find(p=>p.id===a.periodId)?.month||'';const pb=state.arisanPeriods.find(p=>p.id===b.periodId)?.month||'';return pa.localeCompare(pb)});
  if(!rows.length)return `<div class="card" style="margin-top:16px"><h3>Talangan Arisan Aktif</h3><p style="color:var(--muted);margin:0">Tidak ada talangan arisan yang masih aktif.</p></div>`;
  return `<div class="card" style="margin-top:16px"><h3>Talangan Arisan Aktif</h3><p style="color:var(--muted);margin-top:0">Talangan dari periode sebelumnya tetap tampil di sini sampai ditandai lunas. Saat lunas, nominal otomatis kembali sebagai pemasukan Kas WK.</p><div class="table-wrap"><table><thead><tr><th>Nama</th><th>Tahun</th><th>Bulan</th><th>Nominal</th><th>Aksi</th></tr></thead><tbody>${rows.map(p=>{const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return `<tr><td><b>${escapeHtml(m?.name||'-')}</b></td><td>${per?yearOfMonth(per.month):'-'}</td><td>${per?monthOnly(per.month):'-'}</td><td>${money(p.amount)}</td><td><button class="btn primary small" onclick="settleTalangan('${p.id}')">Tandai Lunas</button> <button class="btn small" onclick="selectArisanPeriodAndEdit('${p.id}')">Edit</button></td></tr>`}).join('')}</tbody></table></div></div>`;
}
function selectArisanPeriodAndEdit(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId);
  const sel=document.getElementById('payPeriod');
  if(p&&sel){sel.value=p.periodId;renderArisanPaymentBox();setTimeout(()=>openArisanEdit(paymentId),30)}
}
function addArisanPeriod(){try{const month=arisanMonth.value;if(!month)return toast('Bulan periode wajib diisi.');let per=state.arisanPeriods.find(p=>p.month===month);if(per){per.amount=arisanPeriodAmount();per.receiverName=receiverName.value.trim();per.note=periodNote.value.trim();per.status='Aktif';per.autoCreated=false;toast('Periode arisan berjalan diupdate.')}else{state.arisanPeriods.push({id:uid('ap'),month,amount:arisanPeriodAmount(),receiverName:receiverName.value.trim(),note:periodNote.value.trim(),status:'Aktif',autoCreated:false,namaPeriode:`Arisan ${monthName(month)}`});toast('Periode arisan tersimpan.')}state.settings.activeArisanMonth=month;saveState();renderAll();}catch(e){toast(e.message)}}
function renderArisanPaymentBox(){
  const pid=document.getElementById('payPeriod')?.value,period=state.arisanPeriods.find(p=>p.id===pid),box=document.getElementById('arisanPaymentBox');
  if(!box)return;
  if(!period){box.innerHTML='<p>Belum ada periode arisan.</p>';return}
  const members=arisanMembers().sort((a,b)=>a.name.localeCompare(b.name));
  const paidCount=members.filter(m=>arisanPaymentForMember(pid,m.id)).length;
  const rows=members.map(m=>{
    const pay=arisanPaymentForMember(pid,m.id);
    if(pay){
      const detail=[money(pay.amount),pay.date||'-',pay.method||'-'].join(' | ');
      return `<div class="payment-item paid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><div>${paymentStatusBadge(talanganPaymentLabel(pay))}<b>${escapeHtml(m.name)}</b><small>${escapeHtml(detail)}</small></div><div class="payment-actions"><button class="btn small" onclick="openArisanEdit('${pay.id}')">Edit</button><button class="btn danger small" onclick="deleteArisanPayment('${pay.id}')">Hapus</button></div></div>`;
    }
    return `<label class="payment-item unpaid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><input type="checkbox" value="${m.id}"><div>${paymentStatusBadge('unpaid')}<b>${escapeHtml(m.name)}</b><small>Belum bayar periode ${escapeHtml(monthName(period.month))}</small></div></label>`;
  }).join('');
  box.innerHTML=`<div class="row" style="margin-top:14px"><div><label>Tanggal transaksi</label><input id="arisanPayDate" type="date" value="${todayIso()}"></div><div><label>Metode bayar</label><select id="arisanMethod"><option>Tunai</option><option>Transfer</option><option>QRIS</option><option>Ditalangi Kas WK</option></select></div></div><div class="row"><div><label>Bayar sampai periode</label><input id="arisanPayUntil" type="month" value="${period.month}"></div><div><label>Nominal otomatis</label><input value="${money(arisanPeriodAmount())} / orang / periode" disabled></div></div><small style="display:block;color:var(--muted);margin-top:6px">Untuk bayar lunas sampai Desember, pilih bulan akhir Desember. Aplikasi akan membuat catatan pembayaran per bulan. Talangan Kas WK hanya boleh untuk satu periode.</small><div class="payment-summary"><b>Status periode ${escapeHtml(monthName(period.month))}</b><span>${paidCount}/${members.length} anggota sudah bayar</span></div><label>Cari nama</label><input placeholder="Cari anggota..." oninput="filterChecks('arisanChecks',this.value)"><div id="arisanEditBox"></div><div id="arisanChecks" class="check-list payment-list" style="margin-top:10px">${rows||'<p>Belum ada anggota arisan aktif.</p>'}</div><div class="actions"><button class="btn primary" onclick="saveArisanPayments('${period.id}')">Simpan Pembayaran yang Dicentang</button></div>`;
}
function filterChecks(id,q){q=String(q||'').toLowerCase();document.querySelectorAll(`#${id} .check-item`).forEach(el=>el.style.display=el.dataset.name.includes(q)?'flex':'none')}
function saveArisanPayments(periodId){
  const period=state.arisanPeriods.find(p=>p.id===periodId),ids=[...document.querySelectorAll('#arisanChecks input:checked')].map(i=>i.value);
  if(!period)return toast('Periode arisan tidak ditemukan.');
  if(!ids.length)return toast('Pilih minimal satu anggota yang belum bayar.');
  const method=arisanMethod.value,date=arisanPayDate.value;
  const until=arisanPayUntil?.value||period.month;
  if(until<period.month)return toast('Bulan akhir pembayaran tidak boleh sebelum periode yang dipilih.');
  const months=monthsBetween(period.month,until);
  if(method==='Ditalangi Kas WK'&&months.length>1)return toast('Talangan Kas WK hanya boleh dicatat untuk satu periode.');
  let added=0,skipped=0;
  for(const ym of months){
    const per=ensureArisanPeriod(ym);
    per.amount=arisanPeriodAmount();
    for(const id of ids){
      if(state.arisanPayments.some(p=>p.periodId===per.id&&p.memberId===id)){skipped++;continue;}
      const sumber=method==='Ditalangi Kas WK'?'talangan':'pribadi';
      const payment={id:uid('pay'),periodId:per.id,memberId:id,amount:arisanPeriodAmount(),date,method,sumberBayar:sumber,statusTalangan:sumber==='talangan'?'aktif':'-'};
      state.arisanPayments.push(payment);
      if(sumber==='talangan')syncTalanganCashflow(payment);
      added++;
    }
  }
  saveState();renderAll();toast(added?`Pembayaran arisan tersimpan: ${added} catatan.${skipped?` Duplikat dilewati: ${skipped}.`:''}`:'Tidak ada pembayaran baru.');
}
function openArisanEdit(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId),box=document.getElementById('arisanEditBox');
  if(!p||!box)return toast('Data pembayaran arisan tidak ditemukan.');
  const per=state.arisanPeriods.find(x=>x.id===p.periodId);
  const method=p.sumberBayar==='talangan'?'Ditalangi Kas WK':(p.method||'Tunai');
  box.innerHTML=`<div class="edit-panel"><h4>Edit Pembayaran Arisan</h4><div class="row"><div><label>Anggota</label><select id="editArisanMember">${paymentMemberOptions('arisan',p.memberId)}</select></div><div><label>Nominal dari pengaturan</label><input value="${money(arisanPeriodAmount())}" disabled></div></div><div class="row"><div><label>Tanggal</label><input id="editArisanDate" type="date" value="${p.date||todayIso()}"></div><div><label>Metode</label><select id="editArisanMethod"><option ${selectedOption('Tunai',method)}>Tunai</option><option ${selectedOption('Transfer',method)}>Transfer</option><option ${selectedOption('QRIS',method)}>QRIS</option><option ${selectedOption('Ditalangi Kas WK',method)}>Ditalangi Kas WK</option></select></div></div><div class="row"><div><label>Status talangan</label><select id="editArisanTalangan"><option value="aktif" ${selectedOption('aktif',p.statusTalangan)}>Aktif / belum diganti</option><option value="lunas" ${selectedOption('lunas',p.statusTalangan)}>Lunas / sudah diganti</option></select></div><div><label>Periode</label><input value="${escapeHtml(per?monthName(per.month):'-')}" disabled></div></div><div class="actions"><button class="btn primary" onclick="updateArisanPayment('${p.id}')">Update</button><button class="btn danger" onclick="deleteArisanPayment('${p.id}')">Hapus</button><button class="btn" onclick="renderArisanPaymentBox()">Batal</button></div><small>Gunakan ini untuk memindahkan pembayaran jika sebelumnya salah pilih anggota. Nominal tetap mengikuti Pengaturan.</small></div>`;
}
function updateArisanPayment(paymentId){
  try{
    const p=state.arisanPayments.find(x=>x.id===paymentId);if(!p)return toast('Data pembayaran arisan tidak ditemukan.');
    const old={...p};
    const memberId=editArisanMember.value,amount=arisanPeriodAmount(),date=editArisanDate.value,method=editArisanMethod.value;
    if(state.arisanPayments.some(x=>x.id!==paymentId&&x.periodId===p.periodId&&x.memberId===memberId))return toast('Anggota tersebut sudah tercatat lunas di periode ini.');
    removeLinkedTalanganCashflow(old);
    const sumber=method==='Ditalangi Kas WK'?'talangan':'pribadi';
    Object.assign(p,{memberId,amount,date,method,sumberBayar:sumber,statusTalangan:sumber==='talangan'?editArisanTalangan.value:'-'});
    if(sumber!=='talangan')delete p.tanggalPelunasanTalangan;
    syncTalanganCashflow(p);
    saveState();renderAll();toast('Pembayaran arisan berhasil diupdate.');
  }catch(e){toast(e.message)}
}
function deleteArisanPayment(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId);if(!p)return toast('Data pembayaran arisan tidak ditemukan.');
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  if(!confirm(`Hapus pembayaran arisan ${m?.name||'-'} periode ${per?monthName(per.month):'-'}?`))return;
  removeLinkedTalanganCashflow(p);
  state.arisanPayments=state.arisanPayments.filter(x=>x.id!==paymentId);
  saveState();renderAll();toast('Pembayaran arisan dihapus.');
}
function renderKas(){
  const totals=kasEffectiveTotals();
  const tx=totals.tx.sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  kas.innerHTML=`<div class="card"><h3>Ringkasan Kas</h3><p style="color:var(--muted);margin-top:0">Saldo kas dihitung otomatis dari pembayaran anggota dan pengeluaran kas yang tercatat.</p><div class="grid three"><div class="mini-stat" onclick="detailPemasukanKas()"><b>${money(totals.pemasukan)}</b><span>Uang Kas Masuk</span></div><div class="mini-stat" onclick="detailPengeluaranKas()"><b>${money(totals.pengeluaran)}</b><span>Uang Kas Keluar</span></div><div class="mini-stat" onclick="detailSaldoKas()"><b>${money(totals.saldo)}</b><span>Saldo Kas Saat Ini</span></div></div></div><div class="card" style="margin-top:16px"><h3>Input Iuran Kas Bulanan</h3><p style="color:var(--muted);margin-top:0">Nominal kas mengikuti Pengaturan: <b>${money(kasDefaultAmount())}</b>.</p><div class="row"><div><label>Bulan</label><input id="kasMonth" type="month" value="${currentMonth()}" onchange="renderKasPaymentBox()"></div><div><label>Nominal dari pengaturan</label><input value="${money(kasDefaultAmount())}" disabled></div></div><div id="kasPaymentBox"></div></div><div class="card" style="margin-top:16px"><h3>Riwayat Uang Kas</h3><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Nominal</th><th>Keterangan</th></tr></thead><tbody>${tx.map(t=>`<tr><td>${t.date}</td><td>${t.type==='in'?'Pemasukan':'Pengeluaran'}</td><td>${escapeHtml(t.category||'-')}</td><td>${money(t.amount)}</td><td>${escapeHtml(t.note||'')}</td></tr>`).join('')}</tbody></table></div></div>`;
  renderKasPaymentBox();
}
function renderKasPaymentBox(){
  const box=document.getElementById('kasPaymentBox');if(!box)return;
  const month=document.getElementById('kasMonth')?.value||currentMonth();
  const members=kasMembers().sort((a,b)=>a.name.localeCompare(b.name));
  const paidCount=members.filter(m=>getKasPayment(month,m.id)).length;
  const rows=members.map(m=>{
    const pay=getKasPayment(month,m.id);
    if(pay){
      const detail=[money(pay.amount),pay.date||'-'].join(' | ');
      return `<div class="payment-item paid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><div>${paymentStatusBadge('paid')}<b>${escapeHtml(m.name)}</b><small>${escapeHtml(detail)}</small></div><div class="payment-actions"><button class="btn small" onclick="openKasEdit('${pay.id}')">Edit</button><button class="btn danger small" onclick="deleteKasPayment('${pay.id}')">Hapus</button></div></div>`;
    }
    return `<label class="payment-item unpaid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><input type="checkbox" value="${m.id}"><div>${paymentStatusBadge('unpaid')}<b>${escapeHtml(m.name)}</b><small>Belum bayar ${escapeHtml(monthName(month))}</small></div></label>`;
  }).join('');
  box.innerHTML=`<div class="payment-summary"><b>Status kas ${escapeHtml(monthName(month))}</b><span>${paidCount}/${members.length} anggota sudah bayar</span></div><label>Cari nama</label><input oninput="filterChecks('kasChecks',this.value)" placeholder="Cari anggota..."><div id="kasEditBox"></div><div id="kasChecks" class="check-list payment-list" style="margin-top:10px">${rows||'<p>Belum ada anggota kas aktif.</p>'}</div><button class="primary" onclick="saveKasPayments()">Simpan Iuran Kas yang Dicentang</button>`;
}
function saveKasPayments(){
  try{
    const month=kasMonth.value,amount=kasDefaultAmount(),ids=[...document.querySelectorAll('#kasChecks input:checked')].map(i=>i.value);
    if(!ids.length)return toast('Pilih minimal satu anggota yang belum bayar.');
    let added=0;
    ids.forEach(id=>{if(state.kasPayments.some(p=>p.month===month&&p.memberId===id))return;state.kasPayments.push({id:uid('kp'),month,memberId:id,amount,date:todayIso()});added++;});
    replaceKasIuranTransaction(month);
    saveState();renderAll();toast(added?`Iuran kas tersimpan: ${added} anggota.`:'Tidak ada pembayaran baru.');
  }catch(e){toast(e.message)}
}
function openKasEdit(paymentId){
  const p=state.kasPayments.find(x=>x.id===paymentId),box=document.getElementById('kasEditBox');
  if(!p||!box)return toast('Data iuran kas tidak ditemukan.');
  box.innerHTML=`<div class="edit-panel"><h4>Edit Iuran Kas</h4><div class="row"><div><label>Anggota</label><select id="editKasMember">${paymentMemberOptions('kas',p.memberId)}</select></div><div><label>Bulan</label><input id="editKasMonth" type="month" value="${p.month||currentMonth()}"></div></div><div class="row"><div><label>Nominal dari pengaturan</label><input value="${money(kasDefaultAmount())}" disabled></div><div><label>Tanggal</label><input id="editKasDate" type="date" value="${p.date||todayIso()}"></div></div><div class="actions"><button class="btn primary" onclick="updateKasPayment('${p.id}')">Update</button><button class="btn danger" onclick="deleteKasPayment('${p.id}')">Hapus</button><button class="btn" onclick="renderKasPaymentBox()">Batal</button></div><small>Gunakan ini untuk memindahkan pembayaran jika sebelumnya salah pilih anggota.</small></div>`;
}
function updateKasPayment(paymentId){
  try{
    const p=state.kasPayments.find(x=>x.id===paymentId);if(!p)return toast('Data iuran kas tidak ditemukan.');
    const oldMonth=p.month,newMonth=editKasMonth.value,memberId=editKasMember.value,amount=kasDefaultAmount(),date=editKasDate.value;
    if(state.kasPayments.some(x=>x.id!==paymentId&&x.month===newMonth&&x.memberId===memberId))return toast('Anggota tersebut sudah tercatat lunas di bulan ini.');
    Object.assign(p,{month:newMonth,memberId,amount,date});
    replaceKasIuranTransaction(oldMonth);
    if(newMonth!==oldMonth)replaceKasIuranTransaction(newMonth);
    saveState();renderAll();toast('Iuran kas berhasil diupdate.');
  }catch(e){toast(e.message)}
}
function deleteKasPayment(paymentId){
  const p=state.kasPayments.find(x=>x.id===paymentId);if(!p)return toast('Data iuran kas tidak ditemukan.');
  const m=findMember(p.memberId);
  if(!confirm(`Hapus iuran kas ${m?.name||'-'} bulan ${monthName(p.month)}?`))return;
  const oldMonth=p.month;
  state.kasPayments=state.kasPayments.filter(x=>x.id!==paymentId);
  replaceKasIuranTransaction(oldMonth);
  saveState();renderAll();toast('Iuran kas dihapus.');
}
function getArisanDueRows(endMonth=reportEndMonth()){
  const rows=[];
  const periodGroups={};
  state.arisanPeriods.filter(per=>!endMonth||String(per.month||'')<=endMonth).forEach(per=>{
    const ym=per.month||currentMonth();
    periodGroups[ym]=periodGroups[ym]||[];
    periodGroups[ym].push(per);
  });
  const yms=Object.keys(periodGroups).sort();
  for(const m of arisanMembers().sort((a,b)=>a.name.localeCompare(b.name))){
    const unpaid=[],note=[];
    let total=0;
    for(const ym of yms){
      const periods=periodGroups[ym];
      const paidAny=periods.some(per=>state.arisanPayments.some(p=>p.periodId===per.id&&p.memberId===m.id));
      if(!paidAny){
        unpaid.push(ym);
        const nominal=arisanPeriodAmount();
        total+=nominal;
      }
    }
    const tal=state.arisanPayments.filter(p=>p.memberId===m.id&&p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas');
    if(tal.length)note.push('Ada dana talangan');
    if(unpaid.length)rows.push({member:m,months:unpaid,total,note:note.join(', ')});
  }
  return rows;
}
function renderLaporan(){
  const months=getReportMonths();
  const defaultEnd=months.includes(currentMonth())?currentMonth():(months[months.length-1]||currentMonth());
  laporan.innerHTML=`<div class="card laporan-card"><h3>Laporan & Export</h3><p style="color:var(--muted)">Pilih jenis laporan yang ingin ditampilkan. Untuk file Excel, gunakan tombol Export CSV.</p><div class="row"><div><label>Sampai bulan</label><input id="reportEndMonth" type="month" value="${defaultEnd}" onchange="clearReportArea()"></div><div><label>Jenis laporan</label><select id="reportType"><option value="kas">Belum Bayar Kas</option><option value="arisan">Belum Bayar Arisan</option><option value="kasRekap">Rekap Iuran Kas per Bulan</option><option value="kasMutasi">Riwayat Uang Kas</option><option value="arisanRekap">Rekap Pembayaran Arisan</option><option value="talangan">Talangan Aktif</option><option value="talanganLunas">Riwayat Talangan Lunas</option></select></div></div><div class="actions"><button class="btn primary" onclick="showSelectedReport()">Tampilkan Laporan</button><button class="btn" onclick="showReport('kas')">Belum Bayar Kas</button><button class="btn" onclick="showReport('arisan')">Belum Bayar Arisan</button><button class="btn" onclick="showReport('kasRekap')">Rekap Kas</button><button class="btn" onclick="showReport('talangan')">Talangan Aktif</button></div><div id="reportArea"></div></div>`;
}
function clearReportArea(){const r=document.getElementById('reportArea');if(r)r.innerHTML='';}
function showSelectedReport(){showReport(document.getElementById('reportType')?.value||'kas');}
function showReport(type){
  const end=reportEndMonth();
  let title='',headers=['Nama','Tahun','Bulan / Periode','Total','Keterangan'],rows=[],actionMode=false,summary=[];
  if(type==='kas'){
    const due=getKasDueRowsUntil(end);
    title='Laporan Belum Bayar Kas';
    headers=['Nama','Tahun','Bulan','Total','Keterangan'];
    rows=splitDueRowsByYear(due.unpaidRows).map(r=>[r.member.name,r.year,compactMonthOnly(r.months),money(r.total),'']);
    summary=[['Periode dihitung',`${monthOnly(due.months[0]||end)} ${yearOfMonth(due.months[0]||end)} s.d. ${monthOnly(end)} ${yearOfMonth(end)}`],['Anggota ikut kas',kasMembers().length],['Sudah bayar / kewajiban',`${due.totalPaid}/${due.totalDue}`],['Total nominal belum bayar',money(due.totalNominalBelum)]];
  }else if(type==='arisan'){
    title='Laporan Belum Bayar Arisan';
    headers=['Nama','Tahun','Bulan','Total','Keterangan'];
    const due=getArisanDueRows(end);
    rows=splitDueRowsByYear(due).map(r=>[r.member.name,r.year,compactMonthOnly(r.months),money(r.total),r.note||'']);
    summary=[['Periode arisan sampai bulan ini',state.arisanPeriods.filter(p=>p.month<=end).length],['Anggota ikut arisan',arisanMembers().length],['Total nominal belum bayar',money(due.reduce((a,b)=>a+Number(b.total||0),0))]];
  }else if(type==='kasRekap'){
    title='Rekap Iuran Kas per Bulan';
    headers=['Tahun','Bulan','Sudah Bayar','Belum Bayar','Nominal Masuk','Nominal Belum','Keterangan'];
    const months=monthsBetween(getKasReportStartMonth(end),end);
    rows=months.map(ym=>{
      const paidIds=new Set(state.kasPayments.filter(p=>p.month===ym).map(p=>p.memberId));
      const paid=kasMembers().filter(m=>paidIds.has(m.id)).length;
      const unpaid=Math.max(kasMembers().length-paid,0);
      const masuk=state.kasPayments.filter(p=>p.month===ym).reduce((a,b)=>a+Number(b.amount||0),0);
      return[yearOfMonth(ym),monthOnly(ym),paid,unpaid,money(masuk),money(unpaid*Number(state.settings.defaultKas||0)),unpaid?'Belum lengkap':'Lunas semua'];
    });
    summary=[['Total bulan',months.length],['Total uang kas masuk',money(state.kasPayments.filter(p=>p.month<=end).reduce((a,b)=>a+Number(b.amount||0),0))],['Catatan','Rekap dihitung dari pembayaran anggota yang tercatat']];
  }else if(type==='kasMutasi'){
    title='Riwayat Uang Kas';
    headers=['Tahun','Tanggal','Jenis','Kategori','Nominal','Keterangan'];
    const tx=effectiveKasTransactions().filter(t=>String(t.date||'').slice(0,7)<=end).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
    rows=tx.map(t=>[yearOfDate(t.date),dateNoYear(t.date),t.type==='in'?'Pemasukan':'Pengeluaran',t.category||'-',money(t.amount),`${t.note||''}`]);
    summary=[['Total uang masuk',money(tx.filter(t=>t.type==='in').reduce((a,b)=>a+Number(b.amount||0),0))],['Total uang keluar',money(tx.filter(t=>t.type==='out').reduce((a,b)=>a+Number(b.amount||0),0))],['Saldo kas saat ini',money(tx.reduce((a,t)=>a+(t.type==='in'?Number(t.amount||0):-Number(t.amount||0)),0))]];
  }else if(type==='arisanRekap'){
    title='Rekap Pembayaran Arisan';
    headers=['Tahun','Bulan','Nominal','Sudah Bayar','Belum Bayar','Penerima','Keterangan'];
    rows=[...state.arisanPeriods].filter(per=>String(per.month||'')<=end).sort((a,b)=>String(a.month).localeCompare(String(b.month))).map(per=>{
      const paidIds=new Set(state.arisanPayments.filter(p=>p.periodId===per.id).map(p=>p.memberId));
      const paid=arisanMembers().filter(m=>paidIds.has(m.id)).length;
      const unpaid=Math.max(arisanMembers().length-paid,0);
      return[yearOfMonth(per.month),monthOnly(per.month),money(arisanPeriodAmount()),paid,unpaid,per.receiverName||'-',per.note||''];
    });
    summary=[['Total periode sampai bulan ini',state.arisanPeriods.filter(p=>p.month<=end).length],['Anggota ikut arisan',arisanMembers().length]];
  }else if(type==='talangan'){
    title='Laporan Talangan Aktif';
    headers=['Nama','Tahun','Bulan','Nominal','Keterangan'];
    actionMode=true;
    rows=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas').sort((a,b)=>{const ma=state.members.find(x=>x.id===a.memberId)?.name||'';const mb=state.members.find(x=>x.id===b.memberId)?.name||'';return ma.localeCompare(mb)}).map(p=>{const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return{id:p.id,cols:[m?.name||'-',per?yearOfMonth(per.month):'-',per?monthOnly(per.month):'-',money(p.amount),'Masih ditalangi Kas WK']}});
    summary=[['Total talangan aktif',money(rows.reduce((a,r)=>a+Number(String((Array.isArray(r)?r:r.cols)[3]).replace(/[^0-9]/g,'')||0),0))]];
  }else{
    title='Riwayat Talangan Lunas';
    headers=['Nama','Tahun','Bulan','Nominal','Keterangan'];
    rows=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan==='lunas').sort((a,b)=>String(b.tanggalPelunasanTalangan||'').localeCompare(String(a.tanggalPelunasanTalangan||''))).map(p=>{const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return[m?.name||'-',per?yearOfMonth(per.month):'-',per?monthOnly(per.month):'-',money(p.amount),`Lunas ${p.tanggalPelunasanTalangan||''}`]});
    summary=[['Total riwayat',rows.length]];
  }
  const plainRows=rows.map(r=>Array.isArray(r)?r:r.cols);
  window.currentReport={title,headers,rows:plainRows,summary};
  const summaryHtml=summary.length?`<div class="report-summary">${summary.map(s=>`<div><b>${escapeHtml(s[0])}</b><span>${escapeHtml(s[1])}</span></div>`).join('')}</div>`:'';
  reportArea.innerHTML=`<div class="report-box"><h2>${escapeHtml(state.settings.orgName)}</h2><h3>${escapeHtml(title)}</h3><p>Tanggal cetak: ${new Date().toLocaleDateString('id-ID')}</p><p><b>Total data:</b> ${plainRows.length}</p>${summaryHtml}<div class="table-wrap"><table class="report-simple"><thead><tr>${headers.map(h=>`<th>${escapeHtml(h)}</th>`).join('')}${actionMode?'<th class="no-print">Aksi</th>':''}</tr></thead><tbody>${rows.map((r,i)=>{const cols=Array.isArray(r)?r:r.cols;return`<tr style="background:${pastel(i)}">${cols.map((c,idx)=>`<td>${idx===0?'<b>':''}${escapeHtml(c)}${idx===0?'</b>':''}</td>`).join('')}${actionMode?`<td class="no-print"><button class="btn primary small" onclick="settleTalangan('${r.id}')">Tandai Lunas</button></td>`:''}</tr>`}).join('')||`<tr><td colspan="${headers.length+(actionMode?1:0)}">Tidak ada data.</td></tr>`}</tbody></table></div><div class="actions no-print"><button class="btn primary" onclick="printReportClean()">Cetak / Simpan PDF</button><button class="btn" onclick="exportCurrentReportCsv()">Export CSV / Excel</button></div></div>`;
}
function printReportClean(){
  const oldTitle=document.title;
  document.title='';
  document.body.classList.add('printing-report');
  setTimeout(()=>{
    window.print();
    setTimeout(()=>{document.title=oldTitle;document.body.classList.remove('printing-report');},800);
  },50);
}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
function exportCurrentReportCsv(){
  const r=window.currentReport;
  if(!r)return toast('Tampilkan laporan dulu.');
  const lines=[];
  lines.push([state.settings.orgName].map(csvCell).join(','));
  lines.push([r.title].map(csvCell).join(','));
  if(r.summary?.length){r.summary.forEach(s=>lines.push(s.map(csvCell).join(',')));lines.push('');}
  lines.push(r.headers.map(csvCell).join(','));
  r.rows.forEach(row=>lines.push(row.map(csvCell).join(',')));
  const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`${r.title.toLowerCase().replace(/[^a-z0-9]+/gi,'_')}_${todayIso()}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}
function settleTalangan(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId);
  if(!p)return toast('Data talangan tidak ditemukan.');
  if(p.statusTalangan==='lunas')return toast('Talangan sudah lunas.');
  const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  if(!confirm(`Tandai talangan ${m?.name||'-'} periode ${per?monthName(per.month):'-'} sebesar ${money(p.amount)} sudah diganti ke Kas WK?`))return;
  p.statusTalangan='lunas';
  p.tanggalPelunasanTalangan=todayIso();
  syncTalanganCashflow(p);
  saveState();renderAll();showReport('talangan');toast('Talangan ditandai lunas dan Kas WK bertambah.');
}
function pastel(i){return['#fff4f4','#f3f4ff','#f1fff7','#fff9e8','#f8f0ff','#eefaff'][i%6]} function shareReport(){
  const r=window.currentReport;
  const text=r?`${r.title}\nTotal data: ${r.rows.length}`:'Laporan Arisan WK sudah dibuat.';
  if(navigator.share)navigator.share({title:'Laporan Arisan WK',text});
  else toast('Fitur share tidak tersedia di browser ini.');
}
function renderPengaturan(){const s=state.settings;pengaturan.innerHTML=`<div class="card"><h3>Pengaturan Organisasi</h3><div class="row"><div><label>Nama organisasi</label><input id="setOrg" value="${escapeHtml(s.orgName)}"></div><div><label>Default iuran arisan</label><input id="setArisan" inputmode="numeric" value="${s.defaultArisan}"></div></div><div class="row"><div><label>Default iuran kas</label><input id="setKas" inputmode="numeric" value="${s.defaultKas}"></div><div><label>Nama bendahara</label><input id="setBendahara" value="${escapeHtml(s.bendahara||'')}"></div></div><button class="primary" onclick="saveSettings()">Simpan Pengaturan</button></div><div class="card" style="margin-top:16px"><h3>Backup & Restore</h3><p style="color:var(--muted)">Backup PWA berupa file JSON ke Download. Untuk backup APK berbentuk .db, gunakan file hasil konversi JSON terlebih dahulu.</p><div class="actions backup-actions"><button class="btn primary" onclick="backupJson()">Backup Data</button><label class="btn file-btn" role="button" tabindex="0">Restore Data <input type="file" accept="application/json,.json" style="display:none" onchange="restoreJson(event)"></label><button class="btn danger" onclick="resetData()">Reset Data</button></div></div>`}
function saveSettings(){try{state.settings.orgName=setOrg.value.trim()||'Wanita Katolik';state.settings.defaultArisan=parseAmount(setArisan.value);state.settings.defaultKas=parseAmount(setKas.value);state.settings.bendahara=setBendahara.value.trim();saveState();renderAll();toast('Pengaturan tersimpan.')}catch(e){toast(e.message)}}
function backupJson(){const blob=new Blob([JSON.stringify({...state,session:false},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`arisan_wk_backup_${new Date().toISOString().replaceAll(':','-').slice(0,19)}.json`;a.click();URL.revokeObjectURL(a.href);toast('Backup diunduh ke folder Download.')}
function restoreJson(e){const file=e.target.files[0];if(!file)return;if(!confirm('Restore akan mengganti data aplikasi saat ini. Lanjutkan?'))return;const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);state=normalizeAppData({...defaultState(),...data,session:true});saveState();renderAll();toast('Restore berhasil.')}catch(err){toast('File backup tidak valid.')}};r.readAsText(file)}
function resetData(){if(confirm('Reset akan menghapus semua data lokal aplikasi. Lanjutkan?')){state=defaultState();state.session=true;saveState();renderAll()}}
document.addEventListener('DOMContentLoaded',()=>{const btn=document.getElementById('loginBtn');btn?.addEventListener('click',handleLogin);document.getElementById('loginPass')?.addEventListener('keydown',e=>{if(e.key==='Enter')handleLogin()});document.getElementById('loginUser')?.addEventListener('keydown',e=>{if(e.key==='Enter')handleLogin()});boot();});
