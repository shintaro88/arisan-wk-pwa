const ADMIN_USER='admin', ADMIN_PASS='wk788748';
const MONTHS=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const storeKey='arisan_wk_pwa_v2'; let state=loadState(); let deferredPrompt=null;
function defaultState(){return{settings:{orgName:'Wanita Katolik',bendahara:'',defaultArisan:50000,defaultKas:10000},members:[],arisanPeriods:[],arisanPayments:[],kasPayments:[],kasTransactions:[],session:false}}
function loadState(){try{const raw=localStorage.getItem(storeKey);return raw?normalizeAppData({...defaultState(),...JSON.parse(raw)}):defaultState()}catch(e){return defaultState()}}
function saveState(){localStorage.setItem(storeKey,JSON.stringify(state))}
function uid(p='id'){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
function currentMonth(d=new Date()){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  return `${y}-${m}`;
}
function todayIso(d=new Date()){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  const day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function normalizeMonthText(text){return String(text||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')}
function inferMonthFromText(text,fallbackYm){const raw=normalizeMonthText(text);const yearMatch=raw.match(/(20\d{2})/);const fallbackYear=String(fallbackYm||currentMonth()).slice(0,4);const year=yearMatch?yearMatch[1]:fallbackYear;const tokens=[['januari','jan',1],['februari','feb',2],['maret','mar',3],['april','apr',4],['mei','may',5],['juni','jun',6],['juli','jul',7],['agustus','agu',8],['august','aug',8],['september','sep',9],['oktober','okt',10],['october','oct',10],['november','nov',11],['desember','des',12],['december','dec',12]];for(const [full,short,num] of tokens){const reFull=new RegExp('(^|[^a-z])'+full+'([^a-z]|$)');const reShort=new RegExp('(^|[^a-z])'+short+'([^a-z]|$)');if(reFull.test(raw)||reShort.test(raw)){return year+'-'+String(num).padStart(2,'0')}}return fallbackYm||currentMonth()}
function normalizeAppData(data){const d={...defaultState(),...data};d.settings={...defaultState().settings,...(data?.settings||{})};d.members=Array.isArray(d.members)?d.members:[];d.arisanPeriods=Array.isArray(d.arisanPeriods)?d.arisanPeriods:[];d.arisanPayments=Array.isArray(d.arisanPayments)?d.arisanPayments:[];d.kasPayments=Array.isArray(d.kasPayments)?d.kasPayments:[];d.kasTransactions=Array.isArray(d.kasTransactions)?d.kasTransactions:[];d.arisanPeriods=d.arisanPeriods.map(p=>{const label=[p.namaPeriode,p.name,p.title,p.note].filter(Boolean).join(' ');const inferred=label?inferMonthFromText(label,p.month):p.month;return {...p,month:inferred||p.month||currentMonth(),amount:Number(p.amount||d.settings.defaultArisan||0)}});d.arisanPayments=d.arisanPayments.map(p=>{const sumber=p.sumberBayar||((p.method||'')==='Ditalangi Kas WK'?'talangan':'pribadi');const status=sumber==='talangan'?(p.statusTalangan||'aktif'):(p.statusTalangan||'-');return {...p,sumberBayar:sumber,statusTalangan:status,amount:Number(p.amount||0)}});return d}
function compactMonths(months){
  const seen=new Set();
  return months.filter(Boolean).filter(m=>{
    const key=String(m).toLowerCase();
    if(seen.has(key))return false;
    seen.add(key);
    return true;
  }).join(' - ');
}
function monthShort(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return String(ym||'-');
  const [y,m]=ym.split('-').map(Number);
  return `${MONTHS[m-1]?.slice(0,3)||''} ${y}`;
}
function monthName(ym){
  if(!/^\d{4}-\d{2}$/.test(String(ym||''))) return String(ym||'-');
  const [y,m]=ym.split('-').map(Number);
  return `${MONTHS[m-1]||''} ${y}`;
}
function money(n){return 'Rp '+Number(n||0).toLocaleString('id-ID')}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),3500)}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function normalizeName(s){return String(s||'').trim().replace(/\s+/g,' ').toLowerCase()}
function parseAmount(v){v=String(v||'').trim();if(!/^\d+$/.test(v))throw new Error('Nominal hanya boleh angka tanpa titik, koma, Rp, atau simbol lain.');return Number(v)}
function activeMembers(){return state.members.filter(m=>m.active!==false)} function kasMembers(){return activeMembers().filter(m=>m.ikutKas)} function arisanMembers(){return activeMembers().filter(m=>m.ikutArisan)}
function findMember(id){return state.members.find(m=>m.id===id)}
function memberDisplayName(id){return findMember(id)?.name||'-'}
function paymentMemberOptions(kind,currentId){
  const base=(kind==='kas'?kasMembers():arisanMembers()).slice();
  const current=findMember(currentId);
  if(current&&!base.some(m=>m.id===current.id))base.push(current);
  return base.sort((a,b)=>a.name.localeCompare(b.name)).map(m=>`<option value="${m.id}" ${m.id===currentId?'selected':''}>${escapeHtml(m.name)}${m.active===false?' (nonaktif)':''}</option>`).join('');
}
function selectedOption(value,current){return String(value||'')===String(current||'')?'selected':''}
function getKasPayment(month,memberId){return state.kasPayments.find(p=>p.month===month&&p.memberId===memberId)}
function replaceKasIuranTransaction(month){
  if(!month)return;
  state.kasTransactions=state.kasTransactions.filter(t=>!(t.type==='in'&&isIuranKasTransaction(t)&&inferKasMonthFromTransaction(t)===month));
  const pays=state.kasPayments.filter(p=>p.month===month);
  if(pays.length){
    state.kasTransactions.push({id:uid('kt'),date:todayIso(),type:'in',category:'Iuran Kas',amount:pays.reduce((a,b)=>a+Number(b.amount||0),0),note:`Iuran kas ${monthName(month)} (${pays.length} anggota)`,referensi:`kas:${month}`});
  }
}
function paymentStatusBadge(status){
  const label=status==='paid'?'Lunas':status==='talangan'?'Talangan Aktif':status==='talanganLunas'?'Talangan Lunas':'Belum';
  const cls=status==='paid'?'ok':status==='talangan'?'warn':status==='talanganLunas'?'blue':'danger';
  return `<span class="badge ${cls}">${label}</span>`;
}
function arisanPaymentForMember(periodId,memberId){return state.arisanPayments.find(p=>p.periodId===periodId&&p.memberId===memberId)}
function talanganPaymentLabel(p){
  if(p?.sumberBayar==='talangan')return p.statusTalangan==='lunas'?'talanganLunas':'talangan';
  return 'paid';
}
function linkedTalanganMatch(t,p,kind){
  if(!t||!p)return false;
  const cat=String(t.category||'').toLowerCase();
  if(kind==='out' && !(t.type==='out'&&cat.includes('talangan arisan')))return false;
  if(kind==='in' && !(t.type==='in'&&cat.includes('pengembalian talangan')))return false;
  if(t.referensi===p.id||t.paymentId===p.id)return true;
  if(Number(t.amount||0)!==Number(p.amount||0))return false;
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  const note=normalizeMonthText([t.note,t.referensi].filter(Boolean).join(' '));
  const memberHit=m?note.includes(normalizeName(m.name)):false;
  const periodToken=per?.id?String(per.id).split('_').pop():'';
  const periodHit=per&&(note.includes(normalizeMonthText(monthName(per.month)))||note.includes(normalizeMonthText(per.namaPeriode||''))||note.includes(normalizeMonthText(per.id))||(periodToken&&note.includes(`periode: ${periodToken}`)));
  const dateHit=p.date&&t.date===p.date;
  return Boolean(memberHit||periodHit||dateHit);
}
function removeLinkedTalanganCashflow(p){
  state.kasTransactions=state.kasTransactions.filter(t=>!(linkedTalanganMatch(t,p,'out')||linkedTalanganMatch(t,p,'in')));
}
function syncTalanganCashflow(p){
  removeLinkedTalanganCashflow(p);
  if(!p||p.sumberBayar!=='talangan')return;
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  state.kasTransactions.push({id:uid('kt'),date:p.date||todayIso(),type:'out',category:'Talangan Arisan',amount:Number(p.amount||0),note:`Talangan arisan ${m?.name||''} periode ${per?monthName(per.month):'-'}`,referensi:p.id});
  if(p.statusTalangan==='lunas'){
    const date=p.tanggalPelunasanTalangan||todayIso();
    p.tanggalPelunasanTalangan=date;
    state.kasTransactions.push({id:uid('kt'),date,type:'in',category:'Pengembalian Talangan',amount:Number(p.amount||0),note:`Pengembalian talangan arisan ${m?.name||''} periode ${per?monthName(per.month):'-'}`,referensi:p.id});
  }
}

function handleLogin(){const u=document.getElementById('loginUser').value.trim();const p=document.getElementById('loginPass').value;if(u===ADMIN_USER&&p===ADMIN_PASS){state.session=true;saveState();document.getElementById('loginMsg').textContent='';boot();setPage('dashboard');toast('Login berhasil.')}else{document.getElementById('loginMsg').textContent='Username atau password salah.'}}
function logout(){state.session=false;saveState();location.reload()}
function boot(){state=normalizeAppData(state);saveState();const loginPage=document.getElementById('loginPage');const appShell=document.getElementById('app');if(state.session){loginPage.classList.add('hidden');appShell.classList.remove('hidden');orgNameDrawer.textContent=state.settings.orgName;todayText.textContent=new Date().toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});renderAll()}else{loginPage.classList.remove('hidden');appShell.classList.add('hidden')}}
function renderAll(){renderDashboard();renderAnggota();renderArisan();renderKas();renderLaporan();renderPengaturan()}
function setPage(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));pageTitle.textContent=({dashboard:'Dashboard',anggota:'Data Anggota',arisan:'Arisan',kas:'Kas WK',laporan:'Laporan',pengaturan:'Pengaturan'})[page]||'Dashboard';drawer.classList.remove('open')}
function toggleDrawer(){drawer.classList.toggle('open')} document.addEventListener('click',e=>{const nav=e.target.closest('.nav[data-page]');if(nav)setPage(nav.dataset.page)});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;installBtn.classList.remove('hidden')}); installBtn?.addEventListener('click',async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null}}); if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js'));
function getCurrentDueArisanPeriod(){const ps=[...state.arisanPeriods].sort((a,b)=>String(a.month).localeCompare(String(b.month)));if(!ps.length)return null;const cm=currentMonth();return ps.find(p=>p.month>=cm&&!p.receiverName)||ps.find(p=>p.month>=cm)||ps[ps.length-1]}
function kasPaymentAmountByMonth(){
  const map={};
  state.kasPayments.forEach(p=>{
    if(!p.month)return;
    map[p.month]=(map[p.month]||0)+Number(p.amount||0);
  });
  return map;
}
function inferKasMonthFromTransaction(t){
  const text=[t?.note,t?.category,t?.date].filter(Boolean).join(' ');
  return inferMonthFromText(text,String(t?.date||'').slice(0,7)||currentMonth());
}
function isIuranKasTransaction(t){
  return String(t?.category||'').toLowerCase().includes('iuran kas');
}
function effectiveKasTransactions(){
  const byPay=kasPaymentAmountByMonth();
  const hasPaymentMonth=new Set(Object.keys(byPay));
  const represented=new Set();
  const result=[];
  [...state.kasTransactions].sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))).forEach(t=>{
    if(t.type==='in'&&isIuranKasTransaction(t)){
      const ym=inferKasMonthFromTransaction(t);
      if(hasPaymentMonth.has(ym)){
        if(represented.has(ym))return;
        represented.add(ym);
        result.push({...t,amount:byPay[ym],note:`Iuran kas ${monthName(ym)} (${state.kasPayments.filter(p=>p.month===ym).length} anggota)`,_consolidated:true});
        return;
      }
    }
    result.push(t);
  });
  Object.keys(byPay).sort().forEach(ym=>{
    if(!represented.has(ym)){
      result.push({id:'calc_'+ym,date:ym+'-01',type:'in',category:'Iuran Kas',amount:byPay[ym],note:`Iuran kas ${monthName(ym)} (${state.kasPayments.filter(p=>p.month===ym).length} anggota)`,_consolidated:true});
    }
  });
  return result;
}
function calcSaldoKas(){
  return effectiveKasTransactions().reduce((a,t)=>a+(t.type==='in'?Number(t.amount||0):-Number(t.amount||0)),0);
}
function getReportMonths(){
  const months=new Set();
  state.kasPayments.forEach(p=>p.month&&months.add(p.month));
  state.arisanPeriods.forEach(p=>p.month&&months.add(p.month));
  state.kasTransactions.forEach(t=>{
    if(t.type==='in'&&isIuranKasTransaction(t))months.add(inferKasMonthFromTransaction(t));
  });
  return [...months].filter(m=>/^\d{4}-\d{2}$/.test(m)).sort();
}
function getKasReportStartMonth(endMonth=currentMonth()){
  const months=getReportMonths().filter(m=>m<=endMonth);
  return months[0]||endMonth;
}
function reportEndMonth(){
  return document.getElementById('reportEndMonth')?.value||currentMonth();
}
function monthsBetween(startYm,endYm){let[sy,sm]=startYm.split('-').map(Number),[ey,em]=endYm.split('-').map(Number);const arr=[];while(sy<ey||(sy===ey&&sm<=em)){arr.push(`${sy}-${String(sm).padStart(2,'0')}`);sm++;if(sm>12){sm=1;sy++}}return arr}
function getKasDueRowsUntil(endMonth){
  const first=getKasReportStartMonth(endMonth);
  const months=monthsBetween(first,endMonth);
  const rows=[];
  let totalDue=0,totalPaid=0,totalNominalBelum=0;
  for(const m of kasMembers().sort((a,b)=>a.name.localeCompare(b.name))){
    const unpaid=[];
    for(const ym of months){
      totalDue++;
      const paid=state.kasPayments.some(p=>p.month===ym&&p.memberId===m.id);
      if(paid)totalPaid++;
      else unpaid.push(ym);
    }
    if(unpaid.length){
      const total=unpaid.length*Number(state.settings.defaultKas||0);
      totalNominalBelum+=total;
      rows.push({member:m,months:unpaid,total});
    }
  }
  return{unpaidRows:rows,totalDue,totalPaid,totalNominalBelum,months};
}
function dashboardData(){const cm=currentMonth(),period=getCurrentDueArisanPeriod(),am=arisanMembers(),km=kasMembers();const paid=period?new Set(state.arisanPayments.filter(p=>p.periodId===period.id).map(p=>p.memberId)):new Set();const belumArisan=period?am.filter(m=>!paid.has(m.id)):[];const kasDue=getKasDueRowsUntil(cm);const talangan=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas');const pemasukanKas=state.kasTransactions.filter(t=>t.type==='in').reduce((a,b)=>a+Number(b.amount||0),0);const pengeluaranKas=state.kasTransactions.filter(t=>t.type==='out').reduce((a,b)=>a+Number(b.amount||0),0);return{cm,active:activeMembers(),am,km,period,belumArisan,kasDue,talangan,saldoKas:calcSaldoKas(),pemasukanKas,pengeluaranKas}}
function renderDashboard(){const d=dashboardData();const arisanTotal=d.period?d.am.length:0,arisanPaid=d.period?arisanTotal-d.belumArisan.length:0,arisanPct=arisanTotal?Math.round(arisanPaid/arisanTotal*100):0,kasPct=d.kasDue.totalDue?Math.round(d.kasDue.totalPaid/d.kasDue.totalDue*100):0;dashboard.innerHTML=`<div class="card"><h3>Monitoring ${escapeHtml(state.settings.orgName)}</h3><p style="color:var(--muted);margin-top:0">Ringkasan arisan, kas, dan talangan dalam satu dashboard.</p><div class="grid two"><div class="card"><h3>Progress Arisan</h3><strong>${arisanPaid}/${arisanTotal} orang</strong><div class="progress"><span style="width:${arisanPct}%"></span></div><small>${d.period?monthName(d.period.month):'Belum ada periode arisan'}</small></div><div class="card"><h3>Progress Kas sampai Bulan Ini</h3><strong>${d.kasDue.totalPaid}/${d.kasDue.totalDue} catatan</strong><div class="progress"><span style="width:${kasPct}%"></span></div><small>Tunggakan kas dihitung sampai ${monthName(d.cm)}</small></div></div></div><h3 class="section-title">Tagihan & Talangan</h3><div class="grid four">${kpi('Belum Bayar Arisan',d.belumArisan.length,'warning','detailBelumArisan()')}${kpi('Belum Bayar Kas',d.kasDue.unpaidRows.length,'warn','detailBelumKas()')}${kpi('Talangan Aktif',d.talangan.length,'primary','detailTalangan()',money(d.talangan.reduce((a,b)=>a+Number(b.amount||0),0)))}${kpi('Penerima arisan terakhir',lastReceiverLabel(),'blue','detailPenerima()')}</div><h3 class="section-title">Keuangan</h3><div class="grid four">${kpi('Saldo Kas',money(d.saldoKas),'ok','setPage(\'kas\')')}${kpi('Pemasukan Kas',money(d.pemasukanKas),'blue','setPage(\'kas\')')}${kpi('Pengeluaran Kas',money(d.pengeluaranKas),'danger','setPage(\'kas\')')}${kpi('Anggota Aktif',d.active.length,'primary','setPage(\'anggota\')')}</div>`}
function kpi(label,value,type,action,hint='Klik untuk detail'){const colors={warning:'#df795f',warn:'#c58b31',primary:'#8a61b4',ok:'#30a46c',blue:'#4a91c5',danger:'#d36a4b'};return`<div class="card kpi" onclick="${action}" style="--primary:${colors[type]||'#7B5A91'}"><div><div class="value">${escapeHtml(value)}</div><div class="label">${escapeHtml(label)}</div></div><div class="hint">${escapeHtml(hint)}</div></div>`}
function detailBelumArisan(){const d=dashboardData();alert(d.belumArisan.length?d.belumArisan.map(m=>m.name).join('\n'):'Tidak ada tunggakan arisan.')} function detailBelumKas(){const r=dashboardData().kasDue.unpaidRows;alert(r.length?r.map(x=>`${x.member.name}: ${compactMonths(x.months)}`).join('\n'):'Tidak ada tunggakan kas.')} function detailTalangan(){const r=dashboardData().talangan.map(p=>{const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return`${m?.name||'-'} | ${per?monthName(per.month):'-'} | ${money(p.amount)}`});alert(r.length?r.join('\n'):'Tidak ada talangan aktif.')} function detailPenerima(){alert(lastReceiverLabel())} function lastReceiverLabel(){const r=state.arisanPeriods.filter(p=>p.receiverName).sort((a,b)=>String(b.month).localeCompare(String(a.month)));return r[0]?.receiverName||'-'}
function renderAnggota(){anggota.innerHTML=`<div class="card"><h3>Tambah Anggota</h3><div class="row"><div><label>Nama anggota</label><input id="memberName" placeholder="Nama lengkap"></div><div><label>Wilayah / Lingkungan</label><input id="memberWilayah" placeholder="Opsional"></div></div><div class="actions"><label><input type="checkbox" id="memberKas" checked style="width:auto"> Ikut Kas WK</label><label><input type="checkbox" id="memberArisan" checked style="width:auto"> Ikut Arisan</label></div><button class="primary" onclick="addMember()">Simpan Anggota</button></div><div class="card" style="margin-top:16px"><h3>Daftar Anggota</h3><input id="searchMember" placeholder="Cari nama anggota..." oninput="renderMemberTable()"><div id="memberTable" style="margin-top:12px"></div></div>`;renderMemberTable()}
function addMember(){const name=memberName.value.trim().replace(/\s+/g,' ');if(!name)return toast('Nama anggota wajib diisi.');if(state.members.some(m=>normalizeName(m.name)===normalizeName(name)))return toast('Nama anggota persis sama sudah ada.');state.members.push({id:uid('m'),name,wilayah:memberWilayah.value.trim(),ikutKas:memberKas.checked,ikutArisan:memberArisan.checked,active:true});saveState();toast('Anggota tersimpan.');renderAll()}
function renderMemberTable(){const q=(document.getElementById('searchMember')?.value||'').toLowerCase();const rows=state.members.filter(m=>m.name.toLowerCase().includes(q)).sort((a,b)=>a.name.localeCompare(b.name));memberTable.innerHTML=`<div class="table-wrap"><table><thead><tr><th>Nama</th><th>Wilayah</th><th>Kas</th><th>Arisan</th><th>Status</th><th>Aksi</th></tr></thead><tbody>${rows.map(m=>`<tr><td><b>${escapeHtml(m.name)}</b></td><td>${escapeHtml(m.wilayah||'-')}</td><td>${m.ikutKas?'Ya':'Tidak'}</td><td>${m.ikutArisan?'Ya':'Tidak'}</td><td>${m.active!==false?'Aktif':'Nonaktif'}</td><td><button class="btn" onclick="toggleMember('${m.id}')">${m.active!==false?'Nonaktifkan':'Aktifkan'}</button></td></tr>`).join('')}</tbody></table></div>`}
function toggleMember(id){const m=state.members.find(x=>x.id===id);if(m){m.active=!(m.active!==false);saveState();renderAll()}}
function renderArisan(){arisan.innerHTML=`<div class="card"><h3>Periode Arisan</h3><div class="row"><div><label>Bulan Periode</label><input id="arisanMonth" type="month" value="${currentMonth()}"></div><div><label>Nominal iuran</label><input id="arisanAmount" inputmode="numeric" value="${state.settings.defaultArisan}"></div></div><div class="row"><div><label>Penerima arisan</label><input id="receiverName" placeholder="Isi jika sudah ada penerima"></div><div><label>Catatan</label><input id="periodNote" placeholder="Opsional"></div></div><button class="primary" onclick="addArisanPeriod()">Simpan Periode</button></div><div class="card" style="margin-top:16px"><h3>Pembayaran Arisan</h3><label>Pilih periode</label><select id="payPeriod" onchange="renderArisanPaymentBox()">${state.arisanPeriods.sort((a,b)=>String(b.month).localeCompare(String(a.month))).map(p=>`<option value="${p.id}">${monthName(p.month)} - ${money(p.amount)}</option>`).join('')}</select><div id="arisanPaymentBox"></div></div>`;renderArisanPaymentBox()}
function addArisanPeriod(){try{const month=arisanMonth.value,amount=parseAmount(arisanAmount.value);if(!month)return toast('Bulan periode wajib diisi.');if(state.arisanPeriods.some(p=>p.month===month))return toast('Periode bulan ini sudah ada.');state.arisanPeriods.push({id:uid('ap'),month,amount,receiverName:receiverName.value.trim(),note:periodNote.value.trim()});saveState();renderAll();toast('Periode arisan tersimpan.')}catch(e){toast(e.message)}}
function renderArisanPaymentBox(){
  const pid=document.getElementById('payPeriod')?.value,period=state.arisanPeriods.find(p=>p.id===pid),box=document.getElementById('arisanPaymentBox');
  if(!box)return;
  if(!period){box.innerHTML='<p>Belum ada periode arisan.</p>';return}
  const members=arisanMembers().sort((a,b)=>a.name.localeCompare(b.name));
  const paidCount=members.filter(m=>arisanPaymentForMember(pid,m.id)).length;
  const rows=members.map(m=>{
    const pay=arisanPaymentForMember(pid,m.id);
    if(pay){
      const detail=[money(pay.amount),pay.date||'-',pay.method||'-'].join(' | ');
      return `<div class="payment-item paid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><div>${paymentStatusBadge(talanganPaymentLabel(pay))}<b>${escapeHtml(m.name)}</b><small>${escapeHtml(detail)}</small></div><div class="payment-actions"><button class="btn small" onclick="openArisanEdit('${pay.id}')">Edit</button><button class="btn danger small" onclick="deleteArisanPayment('${pay.id}')">Hapus</button></div></div>`;
    }
    return `<label class="payment-item unpaid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><input type="checkbox" value="${m.id}"><div>${paymentStatusBadge('unpaid')}<b>${escapeHtml(m.name)}</b><small>Belum bayar periode ${escapeHtml(monthName(period.month))}</small></div></label>`;
  }).join('');
  box.innerHTML=`<div class="row" style="margin-top:14px"><div><label>Tanggal transaksi</label><input id="arisanPayDate" type="date" value="${todayIso()}"></div><div><label>Metode bayar</label><select id="arisanMethod"><option>Tunai</option><option>Transfer</option><option>QRIS</option><option>Ditalangi Kas WK</option></select></div></div><div class="payment-summary"><b>Status periode ${escapeHtml(monthName(period.month))}</b><span>${paidCount}/${members.length} anggota sudah bayar</span></div><label>Cari nama</label><input placeholder="Cari anggota..." oninput="filterChecks('arisanChecks',this.value)"><div id="arisanEditBox"></div><div id="arisanChecks" class="check-list payment-list" style="margin-top:10px">${rows||'<p>Belum ada anggota arisan aktif.</p>'}</div><div class="actions"><button class="btn primary" onclick="saveArisanPayments('${period.id}')">Simpan Pembayaran yang Dicentang</button></div>`;
}
function filterChecks(id,q){q=String(q||'').toLowerCase();document.querySelectorAll(`#${id} .check-item`).forEach(el=>el.style.display=el.dataset.name.includes(q)?'flex':'none')}
function saveArisanPayments(periodId){
  const period=state.arisanPeriods.find(p=>p.id===periodId),ids=[...document.querySelectorAll('#arisanChecks input:checked')].map(i=>i.value);
  if(!period)return toast('Periode arisan tidak ditemukan.');
  if(!ids.length)return toast('Pilih minimal satu anggota yang belum bayar.');
  const method=arisanMethod.value,date=arisanPayDate.value;
  let added=0;
  for(const id of ids){
    if(state.arisanPayments.some(p=>p.periodId===periodId&&p.memberId===id))continue;
    const sumber=method==='Ditalangi Kas WK'?'talangan':'pribadi';
    const payment={id:uid('pay'),periodId,memberId:id,amount:Number(period.amount||0),date,method,sumberBayar:sumber,statusTalangan:sumber==='talangan'?'aktif':'-'};
    state.arisanPayments.push(payment);
    if(sumber==='talangan')syncTalanganCashflow(payment);
    added++;
  }
  saveState();renderAll();toast(added?`Pembayaran arisan tersimpan: ${added} anggota.`:'Tidak ada pembayaran baru.');
}
function openArisanEdit(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId),box=document.getElementById('arisanEditBox');
  if(!p||!box)return toast('Data pembayaran arisan tidak ditemukan.');
  const per=state.arisanPeriods.find(x=>x.id===p.periodId);
  const method=p.sumberBayar==='talangan'?'Ditalangi Kas WK':(p.method||'Tunai');
  box.innerHTML=`<div class="edit-panel"><h4>Edit Pembayaran Arisan</h4><div class="row"><div><label>Anggota</label><select id="editArisanMember">${paymentMemberOptions('arisan',p.memberId)}</select></div><div><label>Nominal</label><input id="editArisanAmount" inputmode="numeric" value="${Number(p.amount||per?.amount||0)}"></div></div><div class="row"><div><label>Tanggal</label><input id="editArisanDate" type="date" value="${p.date||todayIso()}"></div><div><label>Metode</label><select id="editArisanMethod"><option ${selectedOption('Tunai',method)}>Tunai</option><option ${selectedOption('Transfer',method)}>Transfer</option><option ${selectedOption('QRIS',method)}>QRIS</option><option ${selectedOption('Ditalangi Kas WK',method)}>Ditalangi Kas WK</option></select></div></div><div class="row"><div><label>Status talangan</label><select id="editArisanTalangan"><option value="aktif" ${selectedOption('aktif',p.statusTalangan)}>Aktif / belum diganti</option><option value="lunas" ${selectedOption('lunas',p.statusTalangan)}>Lunas / sudah diganti</option></select></div><div><label>Periode</label><input value="${escapeHtml(per?monthName(per.month):'-')}" disabled></div></div><div class="actions"><button class="btn primary" onclick="updateArisanPayment('${p.id}')">Update</button><button class="btn danger" onclick="deleteArisanPayment('${p.id}')">Hapus</button><button class="btn" onclick="renderArisanPaymentBox()">Batal</button></div><small>Gunakan ini untuk memindahkan pembayaran jika sebelumnya salah pilih anggota.</small></div>`;
}
function updateArisanPayment(paymentId){
  try{
    const p=state.arisanPayments.find(x=>x.id===paymentId);if(!p)return toast('Data pembayaran arisan tidak ditemukan.');
    const old={...p};
    const memberId=editArisanMember.value,amount=parseAmount(editArisanAmount.value),date=editArisanDate.value,method=editArisanMethod.value;
    if(state.arisanPayments.some(x=>x.id!==paymentId&&x.periodId===p.periodId&&x.memberId===memberId))return toast('Anggota tersebut sudah tercatat lunas di periode ini.');
    removeLinkedTalanganCashflow(old);
    const sumber=method==='Ditalangi Kas WK'?'talangan':'pribadi';
    Object.assign(p,{memberId,amount,date,method,sumberBayar:sumber,statusTalangan:sumber==='talangan'?editArisanTalangan.value:'-'});
    if(sumber!=='talangan')delete p.tanggalPelunasanTalangan;
    syncTalanganCashflow(p);
    saveState();renderAll();toast('Pembayaran arisan berhasil diupdate.');
  }catch(e){toast(e.message)}
}
function deleteArisanPayment(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId);if(!p)return toast('Data pembayaran arisan tidak ditemukan.');
  const m=findMember(p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  if(!confirm(`Hapus pembayaran arisan ${m?.name||'-'} periode ${per?monthName(per.month):'-'}?`))return;
  removeLinkedTalanganCashflow(p);
  state.arisanPayments=state.arisanPayments.filter(x=>x.id!==paymentId);
  saveState();renderAll();toast('Pembayaran arisan dihapus.');
}
function renderKas(){
  const tx=effectiveKasTransactions().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  kas.innerHTML=`<div class="card"><h3>Saldo Kas Efektif: ${money(calcSaldoKas())}</h3><p style="color:var(--muted)">Saldo dihitung dari mutasi efektif. Jika ada transaksi iuran kas ganda hasil import, nominalnya dikonsolidasikan berdasarkan detail pembayaran anggota.</p></div><div class="card" style="margin-top:16px"><h3>Input Iuran Kas Bulanan</h3><div class="row"><div><label>Bulan</label><input id="kasMonth" type="month" value="${currentMonth()}" onchange="renderKasPaymentBox()"></div><div><label>Nominal per orang</label><input id="kasAmount" inputmode="numeric" value="${state.settings.defaultKas}"></div></div><div id="kasPaymentBox"></div></div><div class="card" style="margin-top:16px"><h3>Mutasi Kas Efektif</h3><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Nominal</th><th>Keterangan</th></tr></thead><tbody>${tx.map(t=>`<tr><td>${t.date}</td><td>${t.type==='in'?'Pemasukan':'Pengeluaran'}</td><td>${escapeHtml(t.category||'-')}</td><td>${money(t.amount)}</td><td>${escapeHtml(t.note||'')}${t._consolidated?' <small>(konsolidasi)</small>':''}</td></tr>`).join('')}</tbody></table></div></div>`;
  renderKasPaymentBox();
}
function renderKasPaymentBox(){
  const box=document.getElementById('kasPaymentBox');if(!box)return;
  const month=document.getElementById('kasMonth')?.value||currentMonth();
  const members=kasMembers().sort((a,b)=>a.name.localeCompare(b.name));
  const paidCount=members.filter(m=>getKasPayment(month,m.id)).length;
  const rows=members.map(m=>{
    const pay=getKasPayment(month,m.id);
    if(pay){
      const detail=[money(pay.amount),pay.date||'-'].join(' | ');
      return `<div class="payment-item paid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><div>${paymentStatusBadge('paid')}<b>${escapeHtml(m.name)}</b><small>${escapeHtml(detail)}</small></div><div class="payment-actions"><button class="btn small" onclick="openKasEdit('${pay.id}')">Edit</button><button class="btn danger small" onclick="deleteKasPayment('${pay.id}')">Hapus</button></div></div>`;
    }
    return `<label class="payment-item unpaid check-item" data-name="${escapeHtml(m.name.toLowerCase())}"><input type="checkbox" value="${m.id}"><div>${paymentStatusBadge('unpaid')}<b>${escapeHtml(m.name)}</b><small>Belum bayar ${escapeHtml(monthName(month))}</small></div></label>`;
  }).join('');
  box.innerHTML=`<div class="payment-summary"><b>Status kas ${escapeHtml(monthName(month))}</b><span>${paidCount}/${members.length} anggota sudah bayar</span></div><label>Cari nama</label><input oninput="filterChecks('kasChecks',this.value)" placeholder="Cari anggota..."><div id="kasEditBox"></div><div id="kasChecks" class="check-list payment-list" style="margin-top:10px">${rows||'<p>Belum ada anggota kas aktif.</p>'}</div><button class="primary" onclick="saveKasPayments()">Simpan Iuran Kas yang Dicentang</button>`;
}
function saveKasPayments(){
  try{
    const month=kasMonth.value,amount=parseAmount(kasAmount.value),ids=[...document.querySelectorAll('#kasChecks input:checked')].map(i=>i.value);
    if(!ids.length)return toast('Pilih minimal satu anggota yang belum bayar.');
    let added=0;
    ids.forEach(id=>{if(state.kasPayments.some(p=>p.month===month&&p.memberId===id))return;state.kasPayments.push({id:uid('kp'),month,memberId:id,amount,date:todayIso()});added++;});
    replaceKasIuranTransaction(month);
    saveState();renderAll();toast(added?`Iuran kas tersimpan: ${added} anggota.`:'Tidak ada pembayaran baru.');
  }catch(e){toast(e.message)}
}
function openKasEdit(paymentId){
  const p=state.kasPayments.find(x=>x.id===paymentId),box=document.getElementById('kasEditBox');
  if(!p||!box)return toast('Data iuran kas tidak ditemukan.');
  box.innerHTML=`<div class="edit-panel"><h4>Edit Iuran Kas</h4><div class="row"><div><label>Anggota</label><select id="editKasMember">${paymentMemberOptions('kas',p.memberId)}</select></div><div><label>Bulan</label><input id="editKasMonth" type="month" value="${p.month||currentMonth()}"></div></div><div class="row"><div><label>Nominal</label><input id="editKasAmount" inputmode="numeric" value="${Number(p.amount||state.settings.defaultKas||0)}"></div><div><label>Tanggal</label><input id="editKasDate" type="date" value="${p.date||todayIso()}"></div></div><div class="actions"><button class="btn primary" onclick="updateKasPayment('${p.id}')">Update</button><button class="btn danger" onclick="deleteKasPayment('${p.id}')">Hapus</button><button class="btn" onclick="renderKasPaymentBox()">Batal</button></div><small>Gunakan ini untuk memindahkan pembayaran jika sebelumnya salah pilih anggota.</small></div>`;
}
function updateKasPayment(paymentId){
  try{
    const p=state.kasPayments.find(x=>x.id===paymentId);if(!p)return toast('Data iuran kas tidak ditemukan.');
    const oldMonth=p.month,newMonth=editKasMonth.value,memberId=editKasMember.value,amount=parseAmount(editKasAmount.value),date=editKasDate.value;
    if(state.kasPayments.some(x=>x.id!==paymentId&&x.month===newMonth&&x.memberId===memberId))return toast('Anggota tersebut sudah tercatat lunas di bulan ini.');
    Object.assign(p,{month:newMonth,memberId,amount,date});
    replaceKasIuranTransaction(oldMonth);
    if(newMonth!==oldMonth)replaceKasIuranTransaction(newMonth);
    saveState();renderAll();toast('Iuran kas berhasil diupdate.');
  }catch(e){toast(e.message)}
}
function deleteKasPayment(paymentId){
  const p=state.kasPayments.find(x=>x.id===paymentId);if(!p)return toast('Data iuran kas tidak ditemukan.');
  const m=findMember(p.memberId);
  if(!confirm(`Hapus iuran kas ${m?.name||'-'} bulan ${monthName(p.month)}?`))return;
  const oldMonth=p.month;
  state.kasPayments=state.kasPayments.filter(x=>x.id!==paymentId);
  replaceKasIuranTransaction(oldMonth);
  saveState();renderAll();toast('Iuran kas dihapus.');
}
function getArisanDueRows(){
  const rows=[];
  const periodGroups={};
  state.arisanPeriods.forEach(per=>{
    const ym=per.month||currentMonth();
    periodGroups[ym]=periodGroups[ym]||[];
    periodGroups[ym].push(per);
  });
  const yms=Object.keys(periodGroups).sort();
  for(const m of arisanMembers().sort((a,b)=>a.name.localeCompare(b.name))){
    const unpaid=[],note=[];
    let total=0;
    for(const ym of yms){
      const periods=periodGroups[ym];
      const paidAny=periods.some(per=>state.arisanPayments.some(p=>p.periodId===per.id&&p.memberId===m.id));
      if(!paidAny){
        unpaid.push(ym);
        const nominal=Math.max(...periods.map(per=>Number(per.amount||0)),Number(state.settings.defaultArisan||0));
        total+=nominal;
      }
    }
    const tal=state.arisanPayments.filter(p=>p.memberId===m.id&&p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas');
    if(tal.length)note.push('Ada dana talangan');
    if(unpaid.length)rows.push({member:m,months:unpaid,total,note:note.join(', ')});
  }
  return rows;
}
function renderLaporan(){
  const months=getReportMonths();
  const defaultEnd=months.includes(currentMonth())?currentMonth():(months[months.length-1]||currentMonth());
  laporan.innerHTML=`<div class="card laporan-card"><h3>Laporan & Export</h3><p style="color:var(--muted)">Laporan dihitung dari data JSON detail, bukan hanya dari periode arisan. Untuk file Excel, gunakan tombol Export CSV.</p><div class="row"><div><label>Sampai bulan</label><input id="reportEndMonth" type="month" value="${defaultEnd}" onchange="clearReportArea()"></div><div><label>Jenis laporan</label><select id="reportType"><option value="kas">Belum Bayar Kas</option><option value="arisan">Belum Bayar Arisan</option><option value="kasRekap">Rekap Iuran Kas per Bulan</option><option value="kasMutasi">Mutasi Kas Efektif</option><option value="arisanRekap">Rekap Pembayaran Arisan</option><option value="talangan">Talangan Aktif</option><option value="talanganLunas">Riwayat Talangan Lunas</option></select></div></div><div class="actions"><button class="btn primary" onclick="showSelectedReport()">Tampilkan Laporan</button><button class="btn" onclick="showReport('kas')">Belum Bayar Kas</button><button class="btn" onclick="showReport('arisan')">Belum Bayar Arisan</button><button class="btn" onclick="showReport('kasRekap')">Rekap Kas</button><button class="btn" onclick="showReport('talangan')">Talangan Aktif</button></div><div id="reportArea"></div></div>`;
}
function clearReportArea(){const r=document.getElementById('reportArea');if(r)r.innerHTML='';}
function showSelectedReport(){showReport(document.getElementById('reportType')?.value||'kas');}
function showReport(type){
  const end=reportEndMonth();
  let title='',headers=['Nama','Bulan / Periode','Total','Keterangan'],rows=[],actionMode=false,summary=[];
  if(type==='kas'){
    const due=getKasDueRowsUntil(end);
    title='Laporan Belum Bayar Kas';
    rows=due.unpaidRows.map(r=>[r.member.name,compactMonths(r.months.map(monthShort)),money(r.total),'']);
    summary=[['Periode dihitung',`${monthName(due.months[0]||end)} s.d. ${monthName(end)}`],['Anggota ikut kas',kasMembers().length],['Sudah bayar / kewajiban',`${due.totalPaid}/${due.totalDue}`],['Total nominal belum bayar',money(due.totalNominalBelum)]];
  }else if(type==='arisan'){
    title='Laporan Belum Bayar Arisan';
    const due=getArisanDueRows();
    rows=due.map(r=>[r.member.name,compactMonths(r.months.map(monthName)),money(r.total),r.note||'']);
    summary=[['Periode arisan',state.arisanPeriods.length],['Anggota ikut arisan',arisanMembers().length],['Total nominal belum bayar',money(due.reduce((a,b)=>a+Number(b.total||0),0))]];
  }else if(type==='kasRekap'){
    title='Rekap Iuran Kas per Bulan';
    headers=['Bulan','Sudah Bayar','Belum Bayar','Nominal Masuk','Nominal Belum','Keterangan'];
    const months=monthsBetween(getKasReportStartMonth(end),end);
    rows=months.map(ym=>{
      const paidIds=new Set(state.kasPayments.filter(p=>p.month===ym).map(p=>p.memberId));
      const paid=kasMembers().filter(m=>paidIds.has(m.id)).length;
      const unpaid=Math.max(kasMembers().length-paid,0);
      const masuk=state.kasPayments.filter(p=>p.month===ym).reduce((a,b)=>a+Number(b.amount||0),0);
      return[monthName(ym),paid,unpaid,money(masuk),money(unpaid*Number(state.settings.defaultKas||0)),unpaid?'Belum lengkap':'Lunas semua'];
    });
    summary=[['Total bulan',months.length],['Total kas masuk detail',money(state.kasPayments.filter(p=>p.month<=end).reduce((a,b)=>a+Number(b.amount||0),0))],['Catatan','Rekap memakai kasPayments agar transaksi iuran ganda tidak dobel hitung']];
  }else if(type==='kasMutasi'){
    title='Mutasi Kas Efektif';
    headers=['Tanggal','Jenis','Kategori','Nominal','Keterangan'];
    const tx=effectiveKasTransactions().filter(t=>String(t.date||'').slice(0,7)<=end).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
    rows=tx.map(t=>[t.date||'-',t.type==='in'?'Pemasukan':'Pengeluaran',t.category||'-',money(t.amount),`${t.note||''}${t._consolidated?' (konsolidasi)':''}`]);
    summary=[['Total pemasukan',money(tx.filter(t=>t.type==='in').reduce((a,b)=>a+Number(b.amount||0),0))],['Total pengeluaran',money(tx.filter(t=>t.type==='out').reduce((a,b)=>a+Number(b.amount||0),0))],['Saldo efektif',money(tx.reduce((a,t)=>a+(t.type==='in'?Number(t.amount||0):-Number(t.amount||0)),0))]];
  }else if(type==='arisanRekap'){
    title='Rekap Pembayaran Arisan';
    headers=['Periode','Nominal','Sudah Bayar','Belum Bayar','Penerima','Keterangan'];
    rows=[...state.arisanPeriods].sort((a,b)=>String(a.month).localeCompare(String(b.month))).map(per=>{
      const paidIds=new Set(state.arisanPayments.filter(p=>p.periodId===per.id).map(p=>p.memberId));
      const paid=arisanMembers().filter(m=>paidIds.has(m.id)).length;
      const unpaid=Math.max(arisanMembers().length-paid,0);
      return[monthName(per.month),money(per.amount),paid,unpaid,per.receiverName||'-',per.note||''];
    });
    summary=[['Total periode',state.arisanPeriods.length],['Anggota ikut arisan',arisanMembers().length]];
  }else if(type==='talangan'){
    title='Laporan Talangan Aktif';
    actionMode=true;
    rows=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan!=='lunas').sort((a,b)=>{const ma=state.members.find(x=>x.id===a.memberId)?.name||'';const mb=state.members.find(x=>x.id===b.memberId)?.name||'';return ma.localeCompare(mb)}).map(p=>{const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return{id:p.id,cols:[m?.name||'-',per?monthName(per.month):'-',money(p.amount),'Masih ditalangi Kas WK']}});
    summary=[['Total talangan aktif',money(rows.reduce((a,r)=>a+Number(String((Array.isArray(r)?r:r.cols)[2]).replace(/[^0-9]/g,'')||0),0))]];
  }else{
    title='Riwayat Talangan Lunas';
    rows=state.arisanPayments.filter(p=>p.sumberBayar==='talangan'&&p.statusTalangan==='lunas').sort((a,b)=>String(b.tanggalPelunasanTalangan||'').localeCompare(String(a.tanggalPelunasanTalangan||''))).map(p=>{const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);return[m?.name||'-',per?monthName(per.month):'-',money(p.amount),`Lunas ${p.tanggalPelunasanTalangan||''}`]});
    summary=[['Total riwayat',rows.length]];
  }
  const plainRows=rows.map(r=>Array.isArray(r)?r:r.cols);
  window.currentReport={title,headers,rows:plainRows,summary};
  const summaryHtml=summary.length?`<div class="report-summary">${summary.map(s=>`<div><b>${escapeHtml(s[0])}</b><span>${escapeHtml(s[1])}</span></div>`).join('')}</div>`:'';
  reportArea.innerHTML=`<div class="report-box"><h2>${escapeHtml(state.settings.orgName)}</h2><h3>${escapeHtml(title)}</h3><p>Tanggal cetak: ${new Date().toLocaleDateString('id-ID')}</p><p><b>Total data:</b> ${plainRows.length}</p>${summaryHtml}<div class="table-wrap"><table class="report-simple"><thead><tr>${headers.map(h=>`<th>${escapeHtml(h)}</th>`).join('')}${actionMode?'<th class="no-print">Aksi</th>':''}</tr></thead><tbody>${rows.map((r,i)=>{const cols=Array.isArray(r)?r:r.cols;return`<tr style="background:${pastel(i)}">${cols.map((c,idx)=>`<td>${idx===0?'<b>':''}${escapeHtml(c)}${idx===0?'</b>':''}</td>`).join('')}${actionMode?`<td class="no-print"><button class="btn primary small" onclick="settleTalangan('${r.id}')">Tandai Lunas</button></td>`:''}</tr>`}).join('')||`<tr><td colspan="${headers.length+(actionMode?1:0)}">Tidak ada data.</td></tr>`}</tbody></table></div><div class="actions no-print"><button class="btn primary" onclick="window.print()">Cetak / Simpan PDF</button><button class="btn" onclick="exportCurrentReportCsv()">Export CSV / Excel</button><button class="btn" onclick="shareReport()">Share</button></div></div>`;
}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"';}
function exportCurrentReportCsv(){
  const r=window.currentReport;
  if(!r)return toast('Tampilkan laporan dulu.');
  const lines=[];
  lines.push([state.settings.orgName].map(csvCell).join(','));
  lines.push([r.title].map(csvCell).join(','));
  if(r.summary?.length){r.summary.forEach(s=>lines.push(s.map(csvCell).join(',')));lines.push('');}
  lines.push(r.headers.map(csvCell).join(','));
  r.rows.forEach(row=>lines.push(row.map(csvCell).join(',')));
  const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`${r.title.toLowerCase().replace(/[^a-z0-9]+/gi,'_')}_${todayIso()}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}
function settleTalangan(paymentId){
  const p=state.arisanPayments.find(x=>x.id===paymentId);
  if(!p)return toast('Data talangan tidak ditemukan.');
  if(p.statusTalangan==='lunas')return toast('Talangan sudah lunas.');
  const m=state.members.find(x=>x.id===p.memberId),per=state.arisanPeriods.find(x=>x.id===p.periodId);
  if(!confirm(`Tandai talangan ${m?.name||'-'} periode ${per?monthName(per.month):'-'} sebesar ${money(p.amount)} sudah diganti ke Kas WK?`))return;
  p.statusTalangan='lunas';
  p.tanggalPelunasanTalangan=todayIso();
  syncTalanganCashflow(p);
  saveState();renderAll();showReport('talangan');toast('Talangan ditandai lunas dan Kas WK bertambah.');
}
function pastel(i){return['#fff4f4','#f3f4ff','#f1fff7','#fff9e8','#f8f0ff','#eefaff'][i%6]} function shareReport(){
  const r=window.currentReport;
  const text=r?`${r.title}\nTotal data: ${r.rows.length}`:'Laporan Arisan WK sudah dibuat.';
  if(navigator.share)navigator.share({title:'Laporan Arisan WK',text});
  else toast('Fitur share tidak tersedia di browser ini.');
}
function renderPengaturan(){const s=state.settings;pengaturan.innerHTML=`<div class="card"><h3>Pengaturan Organisasi</h3><div class="row"><div><label>Nama organisasi</label><input id="setOrg" value="${escapeHtml(s.orgName)}"></div><div><label>Default iuran arisan</label><input id="setArisan" inputmode="numeric" value="${s.defaultArisan}"></div></div><div class="row"><div><label>Default iuran kas</label><input id="setKas" inputmode="numeric" value="${s.defaultKas}"></div><div><label>Nama bendahara</label><input id="setBendahara" value="${escapeHtml(s.bendahara||'')}"></div></div><button class="primary" onclick="saveSettings()">Simpan Pengaturan</button></div><div class="card" style="margin-top:16px"><h3>Backup & Restore</h3><p style="color:var(--muted)">Backup PWA berupa file JSON ke Download. Untuk backup APK berbentuk .db, gunakan file hasil konversi JSON terlebih dahulu.</p><div class="actions backup-actions"><button class="btn primary" onclick="backupJson()">Backup Data</button><label class="btn file-btn" role="button" tabindex="0">Restore Data <input type="file" accept="application/json,.json" style="display:none" onchange="restoreJson(event)"></label><button class="btn danger" onclick="resetData()">Reset Data</button></div></div>`}
function saveSettings(){try{state.settings.orgName=setOrg.value.trim()||'Wanita Katolik';state.settings.defaultArisan=parseAmount(setArisan.value);state.settings.defaultKas=parseAmount(setKas.value);state.settings.bendahara=setBendahara.value.trim();saveState();renderAll();toast('Pengaturan tersimpan.')}catch(e){toast(e.message)}}
function backupJson(){const blob=new Blob([JSON.stringify({...state,session:false},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`arisan_wk_backup_${new Date().toISOString().replaceAll(':','-').slice(0,19)}.json`;a.click();URL.revokeObjectURL(a.href);toast('Backup diunduh ke folder Download.')}
function restoreJson(e){const file=e.target.files[0];if(!file)return;if(!confirm('Restore akan mengganti data aplikasi saat ini. Lanjutkan?'))return;const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);state=normalizeAppData({...defaultState(),...data,session:true});saveState();renderAll();toast('Restore berhasil.')}catch(err){toast('File backup tidak valid.')}};r.readAsText(file)}
function resetData(){if(confirm('Reset akan menghapus semua data lokal aplikasi. Lanjutkan?')){state=defaultState();state.session=true;saveState();renderAll()}}
document.addEventListener('DOMContentLoaded',()=>{const btn=document.getElementById('loginBtn');btn?.addEventListener('click',handleLogin);document.getElementById('loginPass')?.addEventListener('keydown',e=>{if(e.key==='Enter')handleLogin()});document.getElementById('loginUser')?.addEventListener('keydown',e=>{if(e.key==='Enter')handleLogin()});boot();});
